﻿function setObject() {

    var myObj = {
        "vertices": [
                    {
                        "name": "Person",
                        "mapping": {
                            "sourceTables": [
                          {
                              "name": "sourceTable1",
                              "dataSource": "mysql",
                              "tableName": "PERSON"
                          },
                          {
                              "name": "sourceTable2",
                              "dataSource": "mysql",
                              "tableName": "VAT_PROFILE"
                          }
                        ],
                            "aggregationFunction": "equality",
                            "columns": ["ID", "ID"]
                        },
                        "properties": [{
                            "name": "extKey1",
                            "include": true,
                            "type": "string",
                            "mandatory": false,
                            "readOnly": false,
                            "notNull": false,
                            "mapping": {
                                "source": "sourceTable1",
                                "columnName": "ID",
                                "type": "VARCHAR"
                            }
                        },
                            {
                                "name": "firstName",
                                "include": true,
                                "type": "string",
                                "mandatory": true,
                                "readOnly": false,
                                "notNull": true,
                                "mapping": {
                                    "source": "sourceTable1",
                                    "columnName": "NAME",
                                    "type": "VARCHAR"
                                }
                            },
                            {
                                "name": "lastName",
                                "include": true,
                                "type": "string",
                                "mandatory": true,
                                "readOnly": false,
                                "notNull": true,
                                "mapping": {
                                    "source": "sourceTable1",
                                    "columnName": "SURNAME",
                                    "type": "VARCHAR"
                                }
                            },
                             {
                                 "name": "depId",
                                 "include": false,
                                 "type": "string",
                                 "mandatory": false,
                                 "readOnly": false,
                                 "notNull": false,
                                 "mapping": {
                                     "source": "sourceTable1",
                                     "columnName": "DEP_ID",
                                     "type": "VARCHAR"
                                 }
                             },
                           {
                               "name": "extKey2",
                               "include": true,
                               "type": "string",
                               "mandatory": false,
                               "readOnly": false,
                               "notNull": false,
                               "mapping": {
                                   "source": "sourceTable2",
                                   "columnName": "ID",
                                   "type": "VARCHAR"
                               }
                           },
                             {
                                 "name": "VAT",
                                 "include": true,
                                 "type": "string",
                                 "mandatory": true,
                                 "readOnly": false,
                                 "notNull": true,
                                 "mapping": {
                                     "source": "sourceTable2",
                                     "columnName": "VAT",
                                     "type": "VARCHAR"
                                 }
                             },
                           {
                               "name": "updatedOn",
                               "include": false,
                               "type": "date",
                               "mandatory": true,
                               "readOnly": false,
                               "notNull": true,
                               "mapping": {
                                   "source": "sourceTable2",
                                   "columnName": "UPDATED_ON",
                                   "type": "DATE"
                               }
                           }
                        ]
                    },
                    {
                        "name": "Project",
                        "mapping": {
                            "sourceTables": [
                          {
                              "name": "sourceTable1",
                              "dataSource": "mysql",
                              "tableName": "PROJECT"
                          }
                        ]
                        },
                        "properties": [
                             {
                                 "name": "id",
                                 "include": true,
                                 "type": "string",
                                 "mandatory": false,
                                 "readOnly": false,
                                 "notNull": false,
                                 "mapping": {
                                     "source": "sourceTable1",
                                     "columnName": "ID",
                                     "type": "VARCHAR"
                                 }
                             },
                            {
                                "name": "projectName",
                                "include": true,
                                "type": "string",
                                "mandatory": true,
                                "readOnly": false,
                                "notNull": true,
                                "mapping": {
                                    "source": "sourceTable1",
                                    "columnName": "NAME",
                                    "type": "VARCHAR"
                                }
                            },
                             {
                                 "name": "location",
                                 "include": true,
                                 "type": "string",
                                 "mandatory": true,
                                 "readOnly": false,
                                 "notNull": true,
                                 "mapping": {
                                     "source": "sourceTable1",
                                     "columnName": "LOCATION",
                                     "type": "VARCHAR"
                                 }
                             },
                            {
                                "name": "updatedOn",
                                "include": false,
                                "type": "date",
                                "mandatory": true,
                                "readOnly": false,
                                "notNull": true,
                                "mapping": {
                                    "source": "sourceTable1",
                                    "columnName": "UPDATED_ON",
                                    "type": "DATE"
                                }
                            }
                        ]
                    },
                     {
                         "name": "Department",
                         "mapping": {
                             "sourceTables": [
                          {
                              "name": "sourceTable1",
                              "dataSource": "mysql",
                              "tableName": "DEPARTMENT"
                          }
                        ]
                         },
                         "properties": [
                             {
                                 "name": "id",
                                 "include": true,
                                 "type": "string",
                                 "mandatory": false,
                                 "readOnly": false,
                                 "notNull": false,
                                 "mapping": {
                                     "source": "sourceTable1",
                                     "columnName": "ID",
                                     "type": "VARCHAR"
                                 }
                             },
                            {
                                "name": "departmentName",
                                "include": true,
                                "type": "string",
                                "mandatory": true,
                                "readOnly": false,
                                "notNull": true,
                                "mapping": {
                                    "source": "sourceTable1",
                                    "columnName": "NAME",
                                    "type": "VARCHAR"
                                }
                            },
                             {
                                 "name": "location",
                                 "include": true,
                                 "type": "string",
                                 "mandatory": true,
                                 "readOnly": false,
                                 "notNull": true,
                                 "mapping": {
                                     "source": "sourceTable1",
                                     "columnName": "LOCATION",
                                     "type": "VARCHAR"
                                 }
                             },
                            {
                                "name": "updatedOn",
                                "include": false,
                                "type": "date",
                                "mandatory": true,
                                "readOnly": false,
                                "notNull": true,
                                "mapping": {
                                    "source": "sourceTable1",
                                    "columnName": "UPDATED_ON",
                                    "type": "DATE"
                                }
                            }
                        ]
                     }
        ],
                                "edges": [
            {
                "WorksAt": {
                    "mapping": {
                        "fromTable": "Person",
                        "fromColumns": ["depId"],
                        "toTable": "Department",
                        "toColumns": ["id"],
                        "direction": "direct"
                    },
                    "properties": {
                        "since": {
                            "include": true,
                            "type": "date",
                            "mandatory": true,
                            "readOnly": false,
                            "notNull": false
                        }
                    }
                }
//                ,
//                "pippo": {
//                    "mapping": {
//                        "fromTable": "Person",
//                        "fromColumns": ["depId"],
//                        "toTable": "Project",
//                        "toColumns": ["id"],
//                        "direction": "direct"
//                    },
//                    "properties": {
//                        "since": {
//                            "include": true,
//                            "type": "date",
//                            "mandatory": true,
//                            "readOnly": false,
//                            "notNull": false
//                        }
//                    }
//                }
            }
          ]

//        "edges": [
//                {

//                    "name": "WorksAt",
//                    "mapping": {
//                        "fromTable": "Person",
//                        "fromColumns": ["depId", "VAT"],
//                        "toTable": "Department",
//                        "toColumns": ["id", "updatedOn"],
//                        "direction": "direct"
//                    },
//                    "properties": {
//                        "since": {
//                            "include": true,
//                            "type": "date",
//                            "mandatory": true,
//                            "readOnly": false,
//                            "notNull": false
//                        }
//                    }

//                }
//         ]
    }

    return myObj;

}

// ** oggeto originale ** //

//function setObject() {

//    var myObj = {        
//  "vertices": [
//    {
//      "name": "Person",
//      "mapping": {
//        "sourceTables": [
//          {
//            "name": "sourceTable1",
//            "dataSource": "mysql",
//            "tableName": "PERSON"
//          },
//          {
//            "name": "sourceTable2",
//            "dataSource": "mysql",
//            "tableName": "VAT_PROFILE"
//          }
//        ],
//        "aggregationFunction": "equality",  
//        "columns": ["ID","ID"]            
//      },                                         
//      "properties": {
//        "extKey1": {
//          "include": true,
//          "type": "string",
//          "mandatory": false,
//          "readOnly": false,
//          "notNull": false,
//          "mapping": {
//            "source": "sourceTable1",
//            "columnName": "ID",
//            "type": "VARCHAR"
//          }
//        },
//        "firstName": {
//          "include": true,
//          "type": "string",
//          "mandatory": true,
//          "readOnly": false,
//          "notNull": true,
//          "mapping": {
//            "source": "sourceTable1",
//            "columnName": "NAME",
//            "type": "VARCHAR"
//          }
//        },
//        "lastName": {
//          "include": true,
//          "type": "string",
//          "mandatory": true,
//          "readOnly": false,
//          "notNull": true,
//          "mapping": {
//            "source": "sourceTable1",
//            "columnName": "SURNAME",
//            "type": "VARCHAR"
//          }
//        },
//        "depId": {
//          "include": false,
//          "type": "string",
//          "mandatory": false,
//          "readOnly": false,
//          "notNull": false,
//          "mapping": {
//            "source": "sourceTable1",
//            "columnName": "DEP_ID",
//            "type": "VARCHAR"
//          }
//        },
//        "extKey2": {
//          "include": true,
//          "type": "string",
//          "mandatory": false,
//          "readOnly": false,
//          "notNull": false,
//          "mapping": {
//            "source": "sourceTable2",
//            "columnName": "ID",
//            "type": "VARCHAR"
//          }
//        },
//        "VAT": {
//          "include": true,
//          "type": "string",
//          "mandatory": true,
//          "readOnly": false,
//          "notNull": true,
//          "mapping": {
//            "source": "sourceTable2",
//            "columnName": "VAT",
//            "type": "VARCHAR"
//          }
//        },
//        "updatedOn": {
//          "include": false,
//          "type": "date",
//          "mandatory": true,
//          "readOnly": false,
//          "notNull": true,
//          "mapping": {
//            "source": "sourceTable2",
//            "columnName": "UPDATED_ON",
//            "type": "DATE"
//          }
//        }
//      }
//    },
//    {
//      "name": "Department",
//      "mapping": {
//        "sourceTables": [
//          {
//            "name": "sourceTable1",
//            "dataSource": "mysql",
//            "tableName": "DEPARTMENT"
//          }
//        ]
//      },
//      "properties": {
//        "id": {
//          "include": true,
//          "type": "string",
//          "mandatory": false,
//          "readOnly": false,
//          "notNull": false,
//          "mapping": {
//            "source": "sourceTable1",
//            "columnName": "ID",
//            "type": "VARCHAR"
//          }
//        },
//        "departmentName": {
//          "include": true,
//          "type": "string",
//          "mandatory": true,
//          "readOnly": false,
//          "notNull": true,
//          "mapping": {
//            "source": "sourceTable1",
//            "columnName": "NAME",
//            "type": "VARCHAR"
//          }
//        },
//        "location": {
//          "include": true,
//          "type": "string",
//          "mandatory": true,
//          "readOnly": false,
//          "notNull": true,
//          "mapping": {
//            "source": "sourceTable1",
//            "columnName": "LOCATION",
//            "type": "VARCHAR"
//          }
//        },
//        "updatedOn": {
//          "include": false,
//          "type": "date",
//          "mandatory": true,
//          "readOnly": false,
//          "notNull": true,
//          "mapping": {
//            "source": "sourceTable1",
//            "columnName": "UPDATED_ON",
//            "type": "DATE"
//          }
//        }
//      }
//    }
//  ],
//  "edges": [
//    {
//      "WorksAt": {
//        "mapping": {
//          "fromTable": "PERSON",
//          "fromColumns": ["DEP_ID"],
//          "toTable": "DEPARTMENT",
//          "toColumns": ["ID"],
//          "direction": "direct"
//        },
//        "properties": {
//          "since": {
//            "include": true,
//            "type": "date",
//            "mandatory": true,
//            "readOnly": false,
//            "notNull": false
//          }
//        }
//      }
//    }
//  ]
//}
//return myObj ;
//}