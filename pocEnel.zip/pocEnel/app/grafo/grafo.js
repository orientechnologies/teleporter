﻿//(function () {
//    'use strict';

    var app = angular.module('app');




    app.directive('vsGrafo', function () {
     
        var directive = {
            link: link,
            restrict: 'A'
        };
        return directive;

        function link($scope, myObj, container, man) {
            container = document.getElementById(container.id);
            $scope.container = container;

            man = $scope.man;
            $scope.$on("redraw", function (event, data) {
                init();
            })
            $scope.$on("addNode", function (event, data) {
                $scope.data.nodes.add({ id: data.mapping.sourceTables[0].tableName, label: data.name, name: data.name });

            })
            $scope.$on("addEdge", function (event, data) {
                $scope.data.edges.add({ id: data.mapping.sourceTables[0].tableName, label: data.name, name: data.name });

            })

            $scope.$on("updateNodo", function (event, data) {
                var etichetta = data.name.substr(0, 7) + "..";
                $scope.data.nodes.update([{ id: data.mapping.sourceTables[0].tableName, label: etichetta, title: data.name, color: { background: "#666666"}}]);
                //nodes.update([{ id: 1, color: { background: newColor}}]);
            })
            $scope.$on("removeNode", function (event, data) {

                $scope.data.nodes.remove({ id: data });

            })
            $scope.$on("renameEdge", function (event, data) {
                $scope.data.edges.update([{ id: data[0], label: data[1]}]);

                //$scope.data.edges.remove({ id: data[0] });
            });

            $scope.$on("removeEdge", function (event, data) {

                $scope.data.edges.remove({ id: data });

            })

            $scope.$on("segnaQuery", function (event, nodo) {
                $scope.data.nodes.update([{ id: nodo, "font": { "color": "green" }, color: { background: '#FF8800', border: 'green' }, highlight: { background: '#FF8800', border: 'green' }, hover: { background: '#FF8800', border: 'green' }
                }]);

            })
            $scope.$on("segnaQueryEdge", function (event, edge) {
                $scope.data.edges.update([{ id: edge, color: 'green', "highlight": { color: 'green', "border": "green" }, "hover": {color: "green", border : 'green' }}]);

            })

            $scope.$on("deleteAllFromQuery", function (event, data) {

                $scope.data.nodes.forEach(function (n) {
                    $scope.data.nodes.update([{ id: n.id, "font": { "color": "#ffffff" }, "color": { "border": "#0e4f67", "background": "#1682ab", "highlight": { "border": "#FF8800", "background": "#FF8800" }, "hover": { "border": "#c26700", "background": "#FF8800"}}}]);

                })
                $scope.data.edges.forEach(function (e) {
                    $scope.data.edges.update([{ id: e.id, color: '#0e4f67'}]);
                })

            })

            $scope.$on("deleteNodeFromQuery", function (event, nome) {

                $scope.data.nodes.update([{ id: nome, "font": { "color": "#ffffff" }, "color": { "border": "#0e4f67", "background": "#1682ab", "highlight": { "border": "#FF8800", "background": "#FF8800" }, "hover": { "border": "#c26700", "background": "#FF8800"}}}]);

            })




            $scope.$on("deleteEdgeFromQuery", function (event, data) {

                //    $scope.data.nodes.update([{ id: data.name, "color": { "border": "#0e4f67", "background": "#1682ab", "highlight": { "border": "#FF8800", "background": "#FF8800" }, "hover": { "border": "#c26700", "background": "#FF8800"}}}]);
                $scope.data.edges.update([{ id: data.name, color: '#0e4f67' }]);
            })

            $scope.$on("updateArco", function (event, data) {
                var ed = {};
                var strArrows = '';
                switch (data.mapping[0].direction) {
                    case ("direct"):
                        strArrows = 'to';
                        break;
                    case ("inverse"):
                        strArrows = 'from';
                        break;
                    case ("both"):
                        strArrows = 'both';
                        break;


                }
                $scope.data.edges.update([{ id: data.name, arrows: strArrows}])


            })

            $scope.options = {
                "nodes": {
                    "physics": true,
                   
                    "color": {
                        "border": "#0e4f67",
                        "background": "#1682ab",
                        "highlight": {
                            "border": "#FF8800",
                            "background": "#FF8800"
                        },
                        "hover": {
                            "border": "#c26700",
                            "background": "#FF8800"
                        }
                    },
                    "font": {
                        "size": 24,
                        "color": "#ffffff"
                    },
                    "shadow": {
                        "enabled": true,
                        "size": 8,
                        "x": 0,
                        "y": 0
                    },
                    "scaling": {
                        "min": 53
                    }
//                    ,shape: 'dot',
//                    size:10,
                    ,  "shape": "circle",
                    "size": 99
                },
                "edges": {
                    "font": {
                        "size": 26,
                        "color": "#0e4f67"
                    },
                    "scaling": {
                        "min": 29,
                        "max": 46
                    },
                    "shadow": {
                        "enabled": false,
                        "size": 0.8,
                        "x": 1,
                        "y": 1
                    },
                    "smooth": {
                        "forceDirection": "none"
                    },
                    "physics": false


                },
                manipulation: {
                    initiallyActive: false,
                    addNode: function (data, callback) {
                        $scope.addNode(data, callback);

                    },
                    deleteEdge: function (data, callback) {
                        $scope.deleteEdge(data, callback);

                    },


                    deleteNode: function (data, callback) {

                        $scope.deleteNode(data, callback);
                    }

                    , addEdge: function (data, callback) {
                        $scope.addEdge(data, callback);

                    }
                },

                "interaction": {
                    hover: true,
                    navigationButtons: true,
                    multiselect: true

                },

                "physics": {
                    "barnesHut": {
                        "avoidOverlap": 1
                    },
                    "minVelocity": 0.75,
                    "solver": "hierarchicalRepulsion"
                }
            }

            if (man == false) {
                $scope.options.manipulation = false;


            }

            function init() {

                $scope.$emit("wait", true);
                var dataTeleporter = $scope.myObj;
                if ($scope.myObj != undefined) {
                    $scope.myObj.edges.forEach(function (a) {
                        for (var k in a) {
                            for (var p in a[k].properties) {
                                a[k].properties[p].rename = p;
                            }
                        }
                    });

                    $scope.myObj.vertices.forEach(function (v) {
                        for (var sourceTable in v.mapping.sourceTables[0]) {

                            for (var key in v.properties) {
                                v.properties[key].rename = key;
                            }

                        }
                    });

                    var nodes = new vis.DataSet([]);
                    var etichetta;
                    $scope.myObj.vertices.forEach(function (v) {
                        if (v.inQuery) {
                            etichetta = v.name.substr(0, 7) + "..";
                            
                             nodes.add({ id: v.mapping.sourceTables[0].tableName, label: etichetta, title: v.name, name: v.name });  //,  color: { background: 'coral',  highlight: { background: 'red' }, hover: { background: 'orange'}} });
//                            nodes.add({ id: v.mapping.sourceTables[0].tableName, label: etichetta, title: v.name, name: v.name });  //,  color: { background: 'coral',  highlight: { background: 'red' }, hover: { background: 'orange'}} });
                        }
                        else {
                            etichetta = v.name.substr(0, 7) + "..";
//                            nodes.add({ id: v.mapping.sourceTables[0].tableName, label: etichetta,  font: {strokeWidth: 3, strokeColor: 'white'}, title: v.name, name: v.name });  //,  color: { background: 'coral',  highlight: { background: 'red' }, hover: { background: 'orange'}} });
                            nodes.add({ id: v.mapping.sourceTables[0].tableName, label: etichetta, title: v.name, name: v.name });
                        }
                    });
                    var edges = new vis.DataSet([]);
                    var ed;

                    dataTeleporter.edges.forEach(function (e) {
                        for (var key in e) {
                            if (e[key].mapping[0].joinTable != undefined) {
                                ed = { id: key, label: key, from: e[key].mapping[0].fromTable, to: e[key].mapping[0].toTable, arrows: 'to,middle, from', dashes: true }; // color: 'red'
                            }
                            else {
                                ed = { id: key, label: key, from: e[key].mapping[0].fromTable, to: e[key].mapping[0].toTable, arrows: 'to' };
                                ed.arrows = e[key].mapping[0].direction == "direct" ? 'to' : e[key].mapping.direction == 'inverse' ? 'from' : 'both';
                            }
                            edges.add(ed);
                        }
                    });
                    //                var data = {
                    //                    nodes: nodes,
                    //                    edges: edges
                    //                };
                    $scope.data = {
                        nodes: nodes,
                        edges: edges
                    };

                    var network = new vis.Network(container, $scope.data, $scope.options);
                    if (man == false) {
                        var toggleManipulation = function (man) {
                            var opt = { manipulation: { enabled: man} };
                            network.setOptions(opt);
                        };
                    }

                    network.on("addEdge", function (params, callback) {
                        var edge = params.edges[0];
                        $scope.SelectEdge(edge);

                        //  network.redraw();
                    });

                    network.on("hoverNode", function (params) {

                    });



                    network.on("deleteNode", function (params) {
                        $scope.deleteNode(params);
                    });

                    network.on("deleteEdge", function (params) {
                        $scope.deleteEdge(params);
                    });
                    network.on("selectNode", function (params) {
                        if (params.nodes.length > 1) {
                            $scope.aggregationStart(params);
                        }
                        else {
                            $scope.selectNode(params.nodes[0], false);
                        }
                    });

                    //                network.on("select", function (params) {
                    //                    $scope.Select(params)
                    //                });

                    network.on("selectEdge", function (params) {
                        if (params.nodes.length == 0) {
                            var edge = params.edges[0];
                            $scope.SelectEdge(edge, false);
                        }
                    });

                    $scope.network = network;
                    $scope.$emit("wait", false);
                }
            }
            init();
        }

    });

//})();