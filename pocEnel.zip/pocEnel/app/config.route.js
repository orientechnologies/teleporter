﻿(function () {
    'use strict';

    var app = angular.module('app');
    // Collect the routes

    app.constant('routes', getRoutes());
    // Configure the routes and route resolvers
    app.config(['$routeProvider', 'routes', routeConfigurator]);

    function routeConfigurator($routeProvider, routes) {
        routes.forEach(function (r) {
            $routeProvider.when(r.url, r.config);
        });
        //  $routeProvider.otherwise({ redirectTo: '/' });
    }

    var dir = '/pocEnel'; 
    // Define the routes 
    function getRoutes() {

        return [
                    {
                        url: '/',
                        config: {
                            templateUrl: window.location.protocol + "//" + window.location.host +   '/pocEnel/app/admin/admin.html',
                            title: 'Struttura',
                            enabled: true,
                            isRoot: true,
                            class: 'fa fa-code-fork fa-lg'
                        }
                    },
                    {
                        url: '/admin',
                        config: {
                            templateUrl: window.location.protocol + "//" + window.location.host + '/pocEnel/app/admin/admin.html',
                            title: 'Struttura',
                            path: 'images/icons/hardware/ic_device_hub_24px.svg',
                            class: "ic ic-struttura",
                            enabled: true,
                            ariaLabel: 'Struttura',
                            settings: {
                                nav: 1,
                                content: '<i class="fa fa-th-list fa-2x"></i> <br/> Struttura'
                            }
                        }
                    },
                     {
                         url: '/querybuilder',
                         config: {
                             templateUrl: window.location.protocol + "//" + window.location.host +  '/pocEnel/app/queryBuilder/querybuilder.htm',
                             class: "ic ic-query-builder",
                             ariaLabel: 'Query Builder',
                             path: 'images/icons/action/ic_query_builder_24px.svg',
                             enabled: false,
                             title: 'Query Builder',
                             settings: {
                                 nav: 1,
                                 content: '<i class="fa fa-th-list fa-2x"></i> <br/> Query Builder'
                             }
                         }
                     }


        ];
    }
})();