﻿(function () {
    'use strict';
    var serviceId = 'serviceTable';
    angular.module('app').factory(serviceId, ['$filter', 'ngTableParams',  serviceTable]);


    function serviceTable($filter, ngTableParams) {

        var service = {
            crea: crea,
            aggiorna :aggiorna
        };

        return service;


        function crea(data) {

            var dataFiltered = data;
            return new ngTableParams({
                page: 1,            // show first page
                count: 10
            }, {
                total: data.length, // length of data
                getData: function ($defer, params) {
                    // use build-in angular filter
                    var orderedData = params.filter() ? $filter('filter')(data, params.filter()) : data;
                    orderedData = params.sorting() ? $filter('orderBy')(orderedData, params.orderBy()) : orderedData;

                    dataFiltered = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());

                    params.total(orderedData.length); // set total for recalc pagination
                    $defer.resolve(dataFiltered);
                }
            });
        }

        function aggiorna(data, filtro) {

            var dataFiltered = data;
            return new ngTableParams({
                page: 1,            // show first page
                count: 10
            }, {
                total: data.length, // length of data
                getData: function ($defer, params) {
                    // use build-in angular filter
                    var orderedData = params.filter() ? $filter('filter')(data, params.filter()) : data;
                    orderedData = params.sorting() ? $filter('orderBy')(orderedData, params.orderBy()) : orderedData;

                    dataFiltered = orderedData.slice((params.page() - 1) * params.count(), params.page() * params.count());

                    params.total(orderedData.length); // set total for recalc pagination
                    $defer.resolve(dataFiltered);
                }
            });
        }
    }
})();