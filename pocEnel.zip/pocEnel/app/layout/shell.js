﻿(function () {
    'use strict';

    var controllerId = 'shell';
    angular.module('app').controller(controllerId,
        ['$scope', '$location', '$timeout', '$rootScope', '$route', 'common', 'config', 'routes', shell]);

    function shell($scope, $location, $timeout, $rootScope, $route, common, config, routes) {
        var vm = this;
        var logSuccess = common.logger.getLogFn(controllerId, 'success');
        var events = config.events;
        //vm.busyMessage = 'Please wait ...';
        vm.busyMessage = 'Operazione in corso ...';
        vm.isBusy = false;
        vm.isDashboard = false;

        vm.spinnerOptions = {
            radius: 25, //40
            lines: 7,
            length: 0,
            width: 15, //30
            speed: 1.7,
            corners: 1.0,
            trail: 100,
            color: '#F58A00'//#F58A00

        };

        $scope.urltopnav = window.location.protocol + "//" + window.location.host + '/pocEnel/app/layout/topnav.html';
        //        $scope.urlsidebar = window.location.protocol + "//" + window.location.host + '/app/layout/sidebar.html';
        $scope.urlfooter = window.location.protocol + "//" + window.location.host + '/pocEnel/app/layout/footer.html';

        var url = location.$$absUrl
        if ($route.current != undefined) {

            var path = $route.current.$$route.title;

        }
        $rootScope.$watch($route.current.$$route.titleth, function () {
            $scope.classActive = $route.current.$$route.title;
        });

        activate();

        function activate() {
            getNavRoutes();
            common.activateController([], controllerId);
        }


        function getNavRoutes() {
            var appRoutes = angular.copy(routes);


            $scope.tabs = appRoutes.filter(function (r) {

                if (!r.config.isRoot) {
                    return r.config;
                }

            }).sort(function (r1, r2) {
                return r1.config;
            });

        }


        function toggleSpinner(on) { vm.isBusy = on; }

        $scope.$on("wait", function (event, on) {
            toggleSpinner(on);

        })
        $rootScope.$on('isConnected', function (event, isConnected) {
            $scope.tabs.forEach(function (t) {
                if (t.url == '/querybuilder') {
                    t.config.enabled = isConnected; // 
                }
            })


        }
        );

        $rootScope.$on('$routeChangeStart',
            function (event, next, current) {

                toggleSpinner(true);

            }
        );

        $rootScope.$on(events.controllerActivateSuccess,
            function (data) {
                if ($route.current != undefined) {
                    if ($route.current.$$route.title != 'dashboard') {
                        vm.isDashboard = false;
                    }
                    else {
                        vm.isDashboard = true;
                    }

                    toggleSpinner(false);
                }
            }
        );

        $rootScope.$on(events.spinnerToggle,
            function (data) { toggleSpinner(data.show); }
        );


        $scope.isCurrent = function (route) {
            if (!route.config.title || !$route.current || !$route.current.title) {
                return '';
            }
            var title = route.config.title;


            return $route.current.title == title ? 'active' : '';
        }
    };
})();