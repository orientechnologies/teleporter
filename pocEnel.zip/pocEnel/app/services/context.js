﻿angular.module('app').service('context', function (common, $base64, $http) {
    this.mock = true;
    this.dbConfig = {
        protocol: "http",
        server: "localhost",
        port: "2480",
        database: "",
        user: 'root',
        psw: 'root'
    }

    this.tpConfig = {
        driver: 'MySQL', // driver name
        // jurl: 'jdbc:mysql://172.16.32.162:3306/POC_DATI', // url del source db
        jurl: 'jdbc:mysql://localhost:3306/poc_dati', // url del source db
        urlDb: '/Users/gabriele/orientdb-enterprise-2.2.12/databases/',
        database: 'PocEnel',
        outDbUrl: '', // url del db di destinazione
        username: 'root',
        password: 'mysql',
        strategy: 'interactive-aggr', // '' naive-aggregate 
        nameResolver: 'java',  // java 
        level: '2', // 3 : warning 4 error 
        excludes: [],
        includes: [],
        xmlPath: '',
        migrationConfig: '',
        mapper: 'basicDBMapper'
    }
    this.classMatch = null;

    this.create = function (tpConfig) {
        this.tpConfig = tpConfig;
    };
    this.destroy = function () {
        this.tpConfig = null;
    };
    this.Drivers = [];

    this.connected = false;

    this.setConnected = function (data) {
        this.connected = data;
    }
    this.isConnected = function () {

        return this.connected;
    }

    this.settpConfig = function (data) {
        if (data == undefined) {
            data = this.tpConfig;
        }
        this.tbConfig = data;
        this.tpConfig.outDbUrl = 'plocal:' + data.urlDb + '\\' + data.database;
        this.dbConfig.database = data.database;
        this.dbConfig.url = this.dbConfig.protocol + '://' + this.dbConfig.server + ':' + this.dbConfig.port + "/command/" + data.database + '/sql/';
        this.dbConfig = {
            protocol: "http",
            server: "localhost",
            port: "2480",
            database: data.database,
            user: 'root',
            psw: 'root'
        };

    }

    this.setdbConfig = function (data) {
        if (data == undefined) {
            data = this.dbConfig;
        }
        this.dbConfig = data;
        this.dbConfig.url = this.dbConfig.protocol + '://' + this.dbConfig.server + ':' + this.dbConfig.port + "/command/" + this.dbConfig.database + '/sql/';
        //url: this.protocol  

    }

    this.getdbConfig = function () {
        return this.dbConfig;
    }


    this.getTpConfig = function () {
        return this.tpConfig;
    }


    this.setObj = function (data) {
        this.obj = data;
        //impostare la sincronizzazione con teleporter
    }

    this.getObjMock = function () {
        this.obj = setObject();
        return this.obj;

    }

    this.getObj = function () {


        return this.obj;

    }

    this.sincronyze = function (obj) {
        var defer = common.$q.defer();
        var result = this.tpConfig;
        tpConfig.migrationConfig = obj;
        return defer.promise;



    }




    this.getDrivers = function () {

        var defer = common.$q.defer();
        var send = this.dbConfig.protocol + "://" + this.dbConfig.server + ":" + this.dbConfig.port + "/teleporter/drivers";
        var auth = $base64.encode(this.dbConfig.user + ':' + this.dbConfig.psw);
        headers = { "Authorization": "Basic " + auth };
        $http.get(send, { headers: headers }).then(function (response) {
            if (response.status == 200) {

                defer.resolve(response);
            }
            else {
                defer.resolve(response);
            }


        }, function (error) {
            defer.resolve(-1);
        })
        return defer.promise;


    }

    this.checkStatus = function () {
        var defer = common.$q.defer();
        var send = this.dbConfig.protocol + "://" + this.dbConfig.server + ":" + this.dbConfig.port + "/teleporter/status";
        var auth = $base64.encode(this.dbConfig.user + ':' + this.dbConfig.psw);
        headers = { "Authorization": "Basic " + auth };
        $http.get(send, { headers: headers }).then(function (response) {
            if (response.status == 200) {
                if (response.data.jobs.length > 0) { // la migrazione è in corso
                    defer.resolve({ esito: 0, job: response.jobs[0] })
                }
                else {
                    defer.resolve({ esito: 1, job: null })
                }
            }

            else {
                defer.resolve(0);
            }
        }, function (error) {
            defer.resolve(-1);
        })
        return defer.promise;
    }

    this.getSchema = function (result) {
        this.settpConfig(result);
        result.strategy = 'naive-aggregate';
        var defer = common.$q.defer();
        var send = this.dbConfig.protocol + "://" + this.dbConfig.server + ":" + this.dbConfig.port + "/teleporter/job";

        var auth = $base64.encode(this.dbConfig.user + ':' + this.dbConfig.psw);
        headers = { "Authorization": "Basic " + auth };
        $http.post(send, result, { headers: headers }).then(function (response) {
            if (response.status == 200 || response.status == 204) {
                defer.resolve(response);
            }
            else {
                defer.resolve(0);
            }
        }, function (error) {
            defer.resolve(-1);
        })
        return defer.promise;
    }

    //    this.getSchema = function () {
    //        var defer = common.$q.defer();
    //        this.checkStatus().then(function (result) {
    //            if (result.STATO == 1) {
    //                var myOby = setObject();
    //                defer.resolve({ STATO: 1, DATA: myOby });
    //            }
    //            else {
    //                defer.resolve(result);
    //            }

    //        });
    //        return defer.promise;
    //    }

    // *** TELEPORTER JOB
    this.tpJob = function (result) {
        this.settpConfig(result);
        var defer = common.$q.defer();
        var send = this.dbConfig.protocol + "://" + this.dbConfig.server + ":" + this.dbConfig.port + "/teleporter/job";

        var auth = $base64.encode(this.dbConfig.user + ':' + this.dbConfig.psw);
        headers = { "Authorization": "Basic " + auth };
        $http.post(send, result, { headers: headers }).then(function (response) {
            if (response.status == 200 || response.status == 204) {
                defer.resolve(response);
            }
            else {
                defer.resolve(0);
            }
        }, function (error) {
            defer.resolve(-1);
        })
        return defer.promise;
    }

    // *****  TELEPORTER STATUS
    this.checkStatusTP = function () {
        var defer = common.$q.defer();
        var send = this.dbConfig.protocol + "://" + this.dbConfig.server + ":" + this.dbConfig.port + "/teleporter/status";
        var auth = $base64.encode(this.dbConfig.user + ':' + this.dbConfig.psw);
        headers = { "Authorization": "Basic " + auth };
        $http.get(send, { headers: headers }).then(function (response) {
            if (response.status == 200) {
                if (response.data.jobs.length > 0) { // la migrazione è in corso
                    defer.resolve({ esito: 0, job: response.data.jobs[0] })
                }
                else { // teleporter non ha job attivi
                    defer.resolve({ esito: 1, job: {} })
                }
            }

            else {
                defer.resolve(0);
            }
        }, function (error) {
            defer.resolve(-1);
        })
        return defer.promise;
    }


    this.verificaDb = function (result) {

        var defer = common.$q.defer();

        var send = this.dbConfig.protocol + "://" + this.dbConfig.server + ":" + this.dbConfig.port + "/listDatabases";


        var auth = $base64.encode(this.dbConfig.user + ':' + this.dbConfig.psw);
        headers = { "Authorization": "Basic " + auth };
        $http.get(send, { headers: headers }).then(function (response) {
            if (response.status == 200 || response.status == 204) {
                response.data.databases.forEach(function (d) {

                    if (d == result.database)
                        defer.resolve(1);

                })


            }
            else {
                defer.resolve(0);
            }
        }, function (error) {
            defer.resolve(-1);
        })
        return defer.promise;


    }


    this.testConnection = function (result) {
        var defer = common.$q.defer();

        var sendListDb = this.dbConfig.protocol + "://" + this.dbConfig.server + ":" + this.dbConfig.port + "/listDatabases";


        //        this.setdbConfig(result);


        var send = this.dbConfig.protocol + "://" + this.dbConfig.server + ":" + this.dbConfig.port + "/connect/" + this.dbConfig.database;
        var auth = $base64.encode(this.dbConfig.user + ':' + this.dbConfig.psw);
        headers = { "Authorization": "Basic " + auth };
        $http.get(send, { headers: headers }).then(function (response) {
            if (response.status == 200 || response.status == 204) {
                defer.resolve(1);
            }
            else {
                defer.resolve(0);
            }
        }, function (error) {
            defer.resolve(-1);
        })
        return defer.promise;
    }

    this.getQueryFromCache = function () {

        return this.classMatch; 
    }

    this.cacheQuery = function (classMatch) {

        this.classMatch = classMatch;


    }


    return this;
})