(function () {
    'use strict';

    var serviceId = 'datacontext';
    angular.module('app').factory(serviceId, ['common', '$http', 'context', datacontext]);

    function datacontext(common, $http, context) {
        var $q = common.$q;

        var service = {
            getItems: getItems,
            deleteItem: deleteItem,
            editItem: editItem,
            getUser: getUser,
            getItemsByFilter: getItemsByFilter,
            salva: salva,
            getFile:getFile
        };

        return service;

        function salva(data, url) {
            var defer = common.$q.defer();
            url = window.location.pathname + "/" + url;
            $http.post(url, data).success(function (data) {
                defer.resolve(data);
            }).error(function (err) {
                defer.reject(err);
            })
            return defer.promise;
        }

        function deleteItem(controllerId, item) {
            var defer = common.$q.defer();
            controllerId = window.location.pathname + "/" + controllerId;
            $http.post(controllerId, item).success(function () {
                defer.resolve(true);
            }).error(function (err) {
                defer.reject(err);
            })
            return defer.promise;
        }

        function editItem(controllerId, item) {
            var defer = common.$q.defer();
            controllerId = window.location.pathname + "/" + controllerId;
            $http.post(controllerId, item).success(function (data) {
                defer.resolve(data);
            }).error(function (err) {
                defer.reject(err);
            })
            return defer.promise;
        }

      

        function getItemsByFilter(controllerId, filter) {
            var defer = common.$q.defer();
            controllerId = window.location.pathname + "/" + controllerId;
            //+ '/', context.incentivo
            $http.post(controllerId, filter).success(function (data) {
                defer.resolve(data);
            })
            .error(function (error) {
                defer.reject(error);
            });
            return defer.promise;
        }


        function getItems(controllerId, filter) {
            var defer = common.$q.defer();
            controllerId = window.location.pathname + "/" + controllerId;
            $http.get(controllerId, filter).success(function (data) {
                defer.resolve(data);
            })
            .error(function (error) {
                defer.reject(error);
            });
            return defer.promise;
        }


        function getUser(controllerId) {
            var defer = common.$q.defer();
            controllerId = window.location.pathname + "/" + controllerId;
            $http.get(controllerId).success(function (data) {
                defer.resolve(data);
            })
            .error(function (error) {
                defer.reject(error);
            });
            return defer.promise;
        }


        function getFile(controllerId, cluster) {
            var defer = common.$q.defer();           
            controllerId = window.location.pathname + "/" + controllerId;
            $http.post(controllerId, cluster).success(function (data) {
                defer.resolve(data);
            })
           .error(function (error) {
               defer.reject(error);
           });
            return defer.promise;

           
        }

       
    }
})();