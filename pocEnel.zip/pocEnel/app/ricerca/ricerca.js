﻿(function () {
    'use strict';
    var controllerId = 'ricerca';

    angular.module('app').controller(controllerId, ['$scope', '$http', 'context', 'common', 'modalService', 'bootstrap.dialog', '$timeout', 'modalService', 'NgTableParams', ricerca]);

    function ricerca($scope, $http, context, common, modal, dialog, $timeout, modalService, NgTableParams) {
        var getLogFn = common.logger.getLogFn;
        var log = getLogFn(controllerId);

        $scope.selection = "query";
        activate();

        //    $scope.tableParams = new NgTableParams({}, { dataset: [{id: 1, valore: "pippo"}] });

        var data = [{ name: "Moroni", age: 50} /*,*/];
        $scope.tableParams = new NgTableParams({}, { dataset: $scope.oggetto });
      

        $scope.save = function () {

            if ($scope.selection == "query") {
                $scope.selection = "result";

            }
            else {
                $scope.selection = "query";
            }

        }
        $scope.eseguiRicerca = function () {


            var oggetto = {
                "vertices": [
                    {
                        "firstName": "Gisella",
                        "lastName": "mormone",
                        "updateOn": "21/01/2016",
                        "location": "Roma"
                    },
                      {
                          "firstName": "Laura",
                          "lastName": "pitone",
                          "updateOn": "21/01/2016",
                          "location": "Roma"
                      },
                       {
                           "firstName": "Massima",
                           "lastName": "pitone",
                           "updateOn": "21/01/2016",
                           "location": "Roma"
                       }],
                "edges": {
                    "amicoDi": {
                        "from": "1",
                        "to": "2",
                        "direction": "direct"
                    }
                }


            }
            $scope.oggetto = oggetto;
            return oggetto;
        }

        $scope.ricerca = function () {


            var method = 'POST';

            $scope.$emit('attesa', controllerId);
            //            $scope.url = 'api/result/get';
            $scope.url = 'http://localhost:2059/Home/getResult';

            $.ajaxSetup({
                xhrFields: {
                    withCredentials: true
                },
                crossDomain: true
            });

            $.ajax({
                type: 'POST',
                url: 'http://localhost:2480/command/RestTester/sql/update Contact set firstName="dan"',
                headers: {
                    "Authorization": "Basic YWRtaW46YWRtaW4="
                },

                success: function (response) {
                    $("#CorsRequest").text(response);

                },
                error: function (error) {

                    // Log any error.
                    console.log("ERROR:", error);

                }

            })


        }




        function getObject() {

            $scope.myObj = context.getObj() // setObject();
            return;
        }


        function clearPopUp() {
            document.getElementById('saveButton').onclick = null;
            document.getElementById('cancelButton').onclick = null;
            document.getElementById('network-popUp').style.display = 'none';
        }

        function cancelEdit(callback) {
            clearPopUp();
            callback(null);
        }

        function saveData(data, callback) {
            data.id = document.getElementById('node-id').value;
            data.label = document.getElementById('node-label').value;
            clearPopUp();
            callback(data);
        }


        function activate() {
            common.activateController([
             getObject()

            ],
             controllerId)
                .then(function () {
                    var container = document.getElementById('mynetwork');
                    $scope.container = container;
                    //                    $scope.ricerca();
                    $scope.eseguiRicerca(); 


                });
        }
    }
})();