﻿(function () {
    'use strict';

    var controllerId = 'sidebar';
    angular.module('app').controller(controllerId,
        ['$route', 'config', 'routes', 'authService', '$rootScope', sidebar]);

    function sidebar($route, config, routes, authService, $rootScope) {
        var vm = this;
        var events = config.events;
        vm.isCurrent = isCurrent;
        vm.url = window.location.pathname;
        if ($route.current) {
            vm.direction = $route.current.params.incentivo || '';
        }
        console.log(vm.direction);
      
        activate();
       
        function activate() { getNavRoutes(); }

        function getNavRoutes() {
            var appRoutes = angular.copy( routes);
            return authService.login().then(function (data) {
               
                      vm.navRoutes = appRoutes.filter(function (r) {
                          return r.config.settings && r.config.settings.nav;
                      
                    }).sort(function (r1, r2) {
                        return r1.config.settings.nav - r2.config.settings.nav;
                    });
                

            });

        }



        $rootScope.$on(events.controllerActivateSuccess,
          function (data) {
              var dir = authService.getIncentivo();
              if ($route.current.$$route.title != 'dashboard')
                  vm.dir = true;
              getNavRoutes();

          }
      );

        function isCurrent(route) {
            if (!route.config.title || !$route.current || !$route.current.title) {
                return '';
            }
            var menuName = route.config.title;
            //if ($route.current.title == "campionamentoDettaglio") {
            //    return menuName == "Simulazione" ? 'current' : '';
            //}
            if ( String($route.current.title).indexOf('campionamento') != -1 ) {
                return menuName == "Simulazione" ? 'current' : '';
            }
            return $route.current.title.substr(0, menuName.length) === menuName ? 'current' : '';
        }
    };
})();
