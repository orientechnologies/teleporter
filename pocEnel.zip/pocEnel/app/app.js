﻿(function () {
    'use strict';

    var app = angular.module('app', [
        // Angular modules 
        'ngAnimate',        // animations
        'ngRoute',          // routing
        'ngSanitize',       // sanitizes html bindings (ex: sidebar.js)
        'base64',
        // Custom modules 
        'common',           // common functions, logger, spinner
        'common.bootstrap', // bootstrap dialog wrapper functions
        // 3rd Party Modules
        'ui.bootstrap',   // ui-bootstrap (ex: carousel, pagination, dialog)
        'ngTable',
        'ui.select',
        'ngMaterial',
        'ngAria'
    ])
     .config(function ($mdThemingProvider) {

         $mdThemingProvider.theme('default')
           .primaryPalette('green', {
               'default': '700', // by default use shade 400 from the pink palette for primary intentions
               'hue-1': '50', // use shade 50 for the <code>md-hue-1</code> class
               'hue-2': '300', // use shade 600 for the <code>md-hue-2</code> class
               'hue-3': 'A200' // use shade A100 for the <code>md-hue-3</code> class
           })
           // If you specify less than all of the keys, it will inherit from the
           // default shades
           .accentPalette('orange', {
               'default': '800', // use shade 200 for default, and keep all other shades the same
               'hue-1': '50', // use shade 50 for the <code>md-hue-1</code> class
               'hue-2': '200', // use shade 600 for the <code>md-hue-2</code> class
               'hue-3': 'A200' // use shade A100 for the <code>md-hue-3</code> class
           })
           .warnPalette('red', {
               'default': '600', // use shade 200 for default, and keep all other shades the same
               'hue-1': '50', // use shade 50 for the <code>md-hue-1</code> class
               'hue-2': '200', // use shade 600 for the <code>md-hue-2</code> class
               'hue-3': 'A200' // use shade A100 for the <code>md-hue-3</code> class
           });
         $mdThemingProvider.theme('custom')
          .primaryPalette('blue-grey')
          .accentPalette('orange')
          .warnPalette('green')

     });

 

    // Handle routing errors and success events
    app.run(['$route', function ($route) {

        // Include $route to kick start the router.
    }]);

 
  
    
    //app.controller('HeaderCtrl', function($scope){
    //    $scope.templates = {template: { url: 'app/layout/shell.html' }  };

    //$scope.template = $scope.templates[0].template;
//});
})();

