﻿function getOptions() {

    var options = {
        "nodes": {
            "color": {
                "highlight": {
                    "border": "rgba(52,233,65,1)"
                },
                "hover": {
                    "border": "rgba(136,233,106,1)"
                }
            },
            "font": {
                "size": 20
            },
            "scaling": {
                "min": 53
            },
            "shape": "circle",
            "size": 99
        },
        "edges": {
            "font": {
                "size": 81
            },
            "scaling": {
                "min": 29,
                "max": 46
            },
            "shadow": {
                "enabled": false,
                "size": 0.2,
                "x": 28,
                "y": 27
            },
            "smooth": {
                "forceDirection": "none"
            }
        },
         manipulation: {
          addNode: function (data, callback) {
            // filling in the popup DOM elements
            document.getElementById('operation').innerHTML = "Add Node";
            document.getElementById('node-id').value = data.id;
            document.getElementById('node-label').value = data.label;
            document.getElementById('saveButton').onclick = saveData.bind(this, data, callback);
            document.getElementById('cancelButton').onclick = clearPopUp.bind();
            document.getElementById('network-popUp').style.display = 'block';
          },
          editNode: function (data, callback) {
            // filling in the popup DOM elements
            document.getElementById('operation').innerHTML = "Edit Node";
            document.getElementById('node-id').value = data.id;
            document.getElementById('node-label').value = data.label;
            document.getElementById('saveButton').onclick = saveData.bind(this, data, callback);
            document.getElementById('cancelButton').onclick = cancelEdit.bind(this,callback);
            document.getElementById('network-popUp').style.display = 'block';
          }
//         , addEdge: function (data, callback) {
//            if (data.from == data.to) {
//              var r = confirm("Do you want to connect the node to itself?");
//              if (r == true) {
//                callback(data);
//              }
//            }
//            else {
//              callback(data);
//            }
//          }
        },
//        "physics": {
//            "minVelocity": 0.75
//        },
        "interaction": { hover: true }
    }
    return options;
}