﻿

// ** oggeto originale ** //

function setObject() {


    var newObj = {
        "vertices": [
        {
            "name": "Pompaalimentatore",
            "mapping": {
                "sourceTables": [
          {
              "name": "sourceTable1",
              "DATETIMESource": "mysql",
              "tableName": "Pompaalimentatore"

          }
        ]

            },
            "properties": {
                "aspirationPressure": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": false,
                    "readOnly": false,
                    "notNull": false,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "aspirationPressure",
                        "type": "VARCHAR"
                    }
                },
                "balanceSystem": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "balanceSystem",
                        "type": "VARCHAR"
                    }
                },
                "componente": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "componente",
                        "type": "VARCHAR"
                    }
                },
                "dataOra": {
                    "include": false,
                    "type": "STRING",
                    "mandatory": false,
                    "readOnly": false,
                    "notNull": false,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "dataOra",
                        "type": "VARCHAR"
                    }
                },
                "description": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": false,
                    "readOnly": false,
                    "notNull": false,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "description",
                        "type": "VARCHAR"
                    }
                },
                "dischargePressure": {
                    "include": true,
                    "type": "INTEGER",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "dischargePressure",
                        "type": "INTEGER"
                    }
                },
                "feedWaterFlow": {
                    "include": false,
                    "type": "STRING",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "feedWaterFlow",
                        "type": "VARCHAR"
                    }
                },
                "id": {
                    "include": true,
                    "type": "INTEGER",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "id",
                        "type": "INTEGER"
                    }
                },
                "unitaProduzione": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "unitaProduzione",
                        "type": "VARCHAR"
                    }
                }
            }
        },
          {
              "name": "Pompabooster",
              "mapping": {
                  "sourceTables": [
          {
              "name": "sourceTable1",
              "DataSource": "mysql",
              "tableName": "Pompabooster"

          }
        ]

              },
              "properties": {
                  "aspirationPressure": {
                      "include": true,
                      "type": "INTEGER",
                      "mandatory": false,
                      "readOnly": false,
                      "notNull": false,
                      "mapping": {
                          "source": "sourceTable1",
                          "columnName": "aspirationPressure",
                          "type": "INTEGER"
                      }
                  },
                  "balanceSystem": {
                      "include": true,
                      "type": "STRING",
                      "mandatory": true,
                      "readOnly": false,
                      "notNull": true,
                      "mapping": {
                          "source": "sourceTable1",
                          "columnName": "balanceSystem",
                          "type": "VARCHAR"
                      }
                  },
                  "componente": {
                      "include": true,
                      "type": "STRING",
                      "mandatory": true,
                      "readOnly": false,
                      "notNull": true,
                      "mapping": {
                          "source": "sourceTable1",
                          "columnName": "componente",
                          "type": "VARCHAR"
                      }
                  },
                  "dataOra": {
                      "include": false,
                      "type": "STRING",
                      "mandatory": false,
                      "readOnly": false,
                      "notNull": false,
                      "mapping": {
                          "source": "sourceTable1",
                          "columnName": "dataOra",
                          "type": "VARCHAR"
                      }
                  },
                  "description": {
                      "include": true,
                      "type": "STRING",
                      "mandatory": false,
                      "readOnly": false,
                      "notNull": false,
                      "mapping": {
                          "source": "sourceTable1",
                          "columnName": "description",
                          "type": "VARCHAR"
                      }
                  },
                  "dischargePressure": {
                      "include": true,
                      "type": "INTEGER",
                      "mandatory": true,
                      "readOnly": false,
                      "notNull": true,
                      "mapping": {
                          "source": "sourceTable1",
                          "columnName": "dischargePressure",
                          "type": "INTEGER"
                      }
                  },
                  "feedWaterFlow": {
                      "include": false,
                      "type": "STRING",
                      "mandatory": true,
                      "readOnly": false,
                      "notNull": true,
                      "mapping": {
                          "source": "sourceTable1",
                          "columnName": "feedWaterFlow",
                          "type": "VARCHAR"
                      }
                  },
                  "unitaProduzione": {
                      "include": false,
                      "type": "STRING",
                      "mandatory": true,
                      "readOnly": false,
                      "notNull": true,
                      "mapping": {
                          "source": "sourceTable1",
                          "columnName": "unitaProduzione",
                          "type": "VARCHAR"
                      }
                  },

                  "id": {
                      "include": false,
                      "type": "INTEGER",
                      "mandatory": true,
                      "readOnly": false,
                      "notNull": true,
                      "mapping": {
                          "source": "sourceTable1",
                          "columnName": "id",
                          "type": "INTEGER"
                      }
                  }
              }
          },
           {
               "name": "Turbinaausiliaria",
               "mapping": {
                   "sourceTables": [
          {
              "name": "sourceTable1",
              "dataSource": "mysql",
              "tableName": "Turbinaausiliaria"

          }
        ]

               },
               "properties": {
                   "aspirationPressure": {
                       "include": true,
                       "type": "INTEGER",
                       "mandatory": false,
                       "readOnly": false,
                       "notNull": false,
                       "mapping": {
                           "source": "sourceTable1",
                           "columnName": "aspirationPressure",
                           "type": "INTEGER"
                       }
                   },
                   "balanceSystem": {
                       "include": true,
                       "type": "STRING",
                       "mandatory": true,
                       "readOnly": false,
                       "notNull": true,
                       "mapping": {
                           "source": "sourceTable1",
                           "columnName": "balanceSystem",
                           "type": "VARCHAR"
                       }
                   },
                   "componente": {
                       "include": true,
                       "type": "STRING",
                       "mandatory": true,
                       "readOnly": false,
                       "notNull": true,
                       "mapping": {
                           "source": "sourceTable1",
                           "columnName": "componente",
                           "type": "VARCHAR"
                       }
                   },
                   "dataOra": {
                       "include": false,
                       "type": "date",
                       "mandatory": false,
                       "readOnly": false,
                       "notNull": false,
                       "mapping": {
                           "source": "sourceTable1",
                           "columnName": "DataOra",
                           "type": "DATETIME"
                       }
                   },
                   "description": {
                       "include": true,
                       "type": "STRING",
                       "mandatory": false,
                       "readOnly": false,
                       "notNull": false,
                       "mapping": {
                           "source": "sourceTable1",
                           "columnName": "description",
                           "type": "VARCHAR"
                       }
                   },

                   "auxiliaryTurbineAuxTurbSideSlowWheelThrustBearingMetalTemp": {
                       "include": true,
                       "type": "STRING",
                       "mandatory": true,
                       "readOnly": false,
                       "notNull": true,
                       "mapping": {
                           "source": "sourceTable1",
                           "columnName": "auxiliaryTurbineAuxTurbSideSlowWheelThrustBearingMetalTemp",
                           "type": "VARCHAR"
                       }
                   },

                   "dischargePressure": {
                       "include": true,
                       "type": "INTEGER",
                       "mandatory": true,
                       "readOnly": false,
                       "notNull": true,
                       "mapping": {
                           "source": "sourceTable1",
                           "columnName": "dischargePressure",
                           "type": "INTEGER"
                       }
                   },
                   "feedWaterFlow": {
                       "include": false,
                       "type": "STRING",
                       "mandatory": true,
                       "readOnly": false,
                       "notNull": true,
                       "mapping": {
                           "source": "sourceTable1",
                           "columnName": "feedWaterFlow",
                           "type": "VARCHAR"
                       }
                   },
                   "unitaProduzione": {
                       "include": false,
                       "type": "STRING",
                       "mandatory": true,
                       "readOnly": false,
                       "notNull": true,
                       "mapping": {
                           "source": "sourceTable1",
                           "columnName": "unitaProduzione",
                           "type": "VARCHAR"
                       }
                   },

                   "id": {
                       "include": false,
                       "type": "INTEGER",
                       "mandatory": true,
                       "readOnly": false,
                       "notNull": true,
                       "mapping": {
                           "source": "sourceTable1",
                           "columnName": "id",
                           "type": "INTEGER"
                       }
                   }
               }
           },
             {
                 "name": "Unitaproduzione",
                 "mapping": {
                     "sourceTables": [
                      {
                          "name": "sourceTable1",
                          "DATETIMESource": "mysql",
                          "tableName": "Unitaproduzione"

                      }
                    ]

                 },
                 "properties": {
                     "inLubeOilTemp": {
                         "include": true,
                         "type": "STRING",
                         "mandatory": false,
                         "readOnly": false,
                         "notNull": false,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "inLubeOilTemp",
                             "type": "VARCHAR"
                         }
                     },
                     "lubeOilCollectorPress": {
                         "include": true,
                         "type": "STRING",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "lubeOilCollectorPress",
                             "type": "VARCHAR"
                         }
                     },
                     "outCondensateTemp": {
                         "include": true,
                         "type": "STRING",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "outCondensateTemp",
                             "type": "VARCHAR"
                         }
                     },
                     "dataOra": {
                         "include": true,
                         "type": "date",
                         "mandatory": false,
                         "readOnly": false,
                         "notNull": false,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "dataOra",
                             "type": "DATETIME"
                         }
                     },
                     "outLubeOilTemp": {
                         "include": true,
                         "type": "STRING",
                         "mandatory": false,
                         "readOnly": false,
                         "notNull": false,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "outLubeOilTemp",
                             "type": "VARCHAR"
                         }
                     },

                     "seaWaterTemp": {
                         "include": true,
                         "type": "STRING",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "seaWaterTemp",
                             "type": "INTEGER"
                         }
                     },

                     "unitaProduzione": {
                         "include": true,
                         "type": "STRING",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "unitaProduzione",
                             "type": "VARCHAR"
                         }
                     },
                     "feedWaterFlow": {
                         "include": false,
                         "type": "date",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "feedWaterFlow",
                             "type": "VARCHAR"
                         }
                     },


                     "id": {
                         "include": false,
                         "type": "date",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "id",
                             "type": "INTEGER"
                         }
                     }
                 }
             },
             {
                 "name": "Generationnotificationevent",
                 "mapping": {
                     "sourceTables": [
          {
              "name": "sourceTable1",
              "dataSource": "mysql",
              "tableName": "Generationnotificationevent"

          }
        ]

                 },
                 "properties": {
                     "completionDate": {
                         "include": true,
                         "type": "STRING",
                         "mandatory": false,
                         "readOnly": false,
                         "notNull": false,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "completionDate",
                             "type": "VARCHAR"
                         }
                     },
                     "description": {
                         "include": true,
                         "type": "STRING",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "description",
                             "type": "VARCHAR"
                         }
                     },
                     "eventTimestamp": {
                         "include": true,
                         "type": "STRING",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "eventTimestamp",
                             "type": "DATETIME"
                         }
                     },
                     "failureEnd": {
                         "include": false,
                         "type": "STRING",
                         "mandatory": false,
                         "readOnly": false,
                         "notNull": false,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "failureEnd",
                             "type": "VARCHAR"
                         }
                     },
                     "failureStart": {
                         "include": true,
                         "type": "STRING",
                         "mandatory": false,
                         "readOnly": false,
                         "notNull": false,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "failureStart",
                             "type": "VARCHAR"
                         }
                     },

                     "functionalLocation": {
                         "include": true,
                         "type": "STRING",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "functionalLocation",
                             "type": "INTEGER"
                         }
                     },

                     "inspectorFullName": {
                         "include": true,
                         "type": "INTEGER",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "inspectorFullName",
                             "type": "INTEGER"
                         }
                     },
                     "inspectorId": {
                         "include": false,
                         "type": "STRING",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "inspectorId",
                             "type": "VARCHAR"
                         }
                     },
                     "name": {
                         "include": false,
                         "type": "STRING",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "name",
                             "type": "VARCHAR"
                         }
                     },
                     "notificationType": {
                         "include": false,
                         "type": "STRING",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "notificationType",
                             "type": "VARCHAR"
                         }
                     },
                     "priority": {
                         "include": false,
                         "type": "STRING",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "priority",
                             "type": "VARCHAR"
                         }
                     },

                     "id": {
                         "include": false,
                         "type": "date",
                         "mandatory": true,
                         "readOnly": false,
                         "notNull": true,
                         "mapping": {
                             "source": "sourceTable1",
                             "columnName": "id",
                             "type": "INTEGER"
                         }
                     }
                 }
             }



        ],



        "edges": [
             {
                 "APPARTIENE": {
                     "mapping": [{
                         "fromTable": "Turbinaausiliaria",
                         "fromColumns": ["unitaProduzione"],
                         "toTable": "Unitaproduzione",
                         "toColumns": ["unitaProduzione"],
                         "direction": "direct"
                     }],
                     "properties": {
                         "since": {
                             "include": true,
                             "type": "date",
                             "mandatory": true,
                             "readOnly": false,
                             "notNull": false
                         }
                     }
                 }
             }
             ,
             { "GENERA":
                    {
                        "mapping": [{
                            "fromTable": "Turbinaausiliaria",
                            "toTable": "Generationnotificationevent",
                            "fromColumns": ["unitaProduzione"],
                            "toColumns": ["notificationType"],
                            "direction": "direct"
                        }],
                        "properties": {}
                    }
             }
             ,
             { "PRODUCE":
                    {
                        "mapping":
                            [{
                                "fromTable": "Unitaproduzione",
                                "toTable": "Pompabooster",
                                "fromColumns": ["id"],
                                "toColumns": ["unitaProduzione"],
                                "direction": "direct"
                            }],
                        "properties": {}
                    }
             }
        //             ,
        //             
        //               {
        //                 "CONTIENE": {
        //                     "mapping": [{
        //                         "toTable": "Turbinaausiliaria",
        //                         "toColumns": ["unitaProduzione"],
        //                         "fromTable": "Unitaproduzione",
        //                         "fromColumns": ["unitaProduzione"],
        //                         "direction": "direct"
        //                     }],
        //                     "properties": {
        //                         "since": {
        //                             "include": true,
        //                             "type": "date",
        //                             "mandatory": true,
        //                             "readOnly": false,
        //                             "notNull": false
        //                         }
        //                     }
        //                 }
        //             }
             ]
    }
    var myObjold = {
        "vertices": [
    {
        "name": "Person",
        "mapping": {
            "sourceTables": [
          {
              "name": "sourceTable1",
              "DATETIMESource": "mysql",
              "tableName": "PERSON",
              "aggregationColumns": ["ID"]
          },
          {
              "name": "sourceTable2",
              "DATETIMESource": "mysql",
              "tableName": "VAT_PROFILE",
              "aggregationColumns": ["ID"]
          }
        ],
            "aggregationFunction": "equality"
        },
        "properties": {
            "extKey1": {
                "include": true,
                "type": "STRING",
                "mandatory": false,
                "readOnly": false,
                "notNull": false,
                "mapping": {
                    "source": "sourceTable1",
                    "columnName": "ID",
                    "type": "VARCHAR"
                }
            },
            "firstName": {
                "include": true,
                "type": "STRING",
                "mandatory": true,
                "readOnly": false,
                "notNull": true,
                "mapping": {
                    "source": "sourceTable1",
                    "columnName": "NAME",
                    "type": "VARCHAR"
                }
            },
            "lastName": {
                "include": true,
                "type": "STRING",
                "mandatory": true,
                "readOnly": false,
                "notNull": true,
                "mapping": {
                    "source": "sourceTable1",
                    "columnName": "SURNAME",
                    "type": "VARCHAR"
                }
            },
            "depId": {
                "include": false,
                "type": "STRING",
                "mandatory": false,
                "readOnly": false,
                "notNull": false,
                "mapping": {
                    "source": "sourceTable1",
                    "columnName": "DEP_ID",
                    "type": "VARCHAR"
                }
            },
            "extKey2": {
                "include": true,
                "type": "STRING",
                "mandatory": false,
                "readOnly": false,
                "notNull": false,
                "mapping": {
                    "source": "sourceTable2",
                    "columnName": "ID",
                    "type": "VARCHAR"
                }
            },
            "VAT": {
                "include": true,
                "type": "STRING",
                "mandatory": true,
                "readOnly": false,
                "notNull": true,
                "mapping": {
                    "source": "sourceTable2",
                    "columnName": "VAT",
                    "type": "VARCHAR"
                }
            },
            "updatedOn": {
                "include": false,
                "type": "date",
                "mandatory": true,
                "readOnly": false,
                "notNull": true,
                "mapping": {
                    "source": "sourceTable2",
                    "columnName": "UPDATED_ON",
                    "type": "DATE"
                }
            }
        }
    },
    {
        "name": "Department",
        "mapping": {
            "sourceTables": [
          {
              "name": "sourceTable1",
              "DATETIMESource": "mysql",
              "tableName": "DEPARTMENT"
          }
        ]
        },
        "properties": {
            "id": {
                "include": true,
                "type": "STRING",
                "mandatory": false,
                "readOnly": false,
                "notNull": false,
                "mapping": {
                    "source": "sourceTable1",
                    "columnName": "ID",
                    "type": "VARCHAR"
                }
            },
            "departmentName": {
                "include": true,
                "type": "STRING",
                "mandatory": true,
                "readOnly": false,
                "notNull": true,
                "mapping": {
                    "source": "sourceTable1",
                    "columnName": "NAME",
                    "type": "VARCHAR"
                }
            },
            "location": {
                "include": true,
                "type": "STRING",
                "mandatory": true,
                "readOnly": false,
                "notNull": true,
                "mapping": {
                    "source": "sourceTable1",
                    "columnName": "LOCATION",
                    "type": "VARCHAR"
                }
            },
            "updatedOn": {
                "include": false,
                "type": "date",
                "mandatory": true,
                "readOnly": false,
                "notNull": true,
                "mapping": {
                    "source": "sourceTable1",
                    "columnName": "UPDATED_ON",
                    "type": "DATE"
                }
            }
        }
    }
  ],
        "edges": [
            {
                "WorksAt": {
                    "mapping": [{
                        "fromTable": "PERSON",
                        "fromColumns": ["DEP_ID"],
                        "toTable": "DEPARTMENT",
                        "toColumns": ["ID"],
                        "direction": "direct"
                    }],
                    "properties": {
                        "since": {
                            "include": true,
                            "type": "date",
                            "mandatory": true,
                            "readOnly": false,
                            "notNull": false
                        }
                    }
                }
            }
  ]
    };




    var myObj = {
        "vertices": [{
            "name": "Person",
            "mapping": {
                "sourceTables": [{
                    "name": "sourceTable1",
                    "DATETIMESource": "mysql",
                    "tableName": "PERSON",
                    "aggregationColumns": ["ID"]

                }, {
                    "name": "sourceTable2",
                    "DATETIMESource": "mysql",
                    "tableName": "VAT_PROFILE",
                    "aggregationColumns": ["ID"]
                }],
                "aggregationFunction": "equality"

            },
            "properties": {
                "extKey1": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": false,
                    "readOnly": false,
                    "notNull": false,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "ID",
                        "type": "VARCHAR"
                    }
                },
                "firstName": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "NAME",
                        "type": "VARCHAR"
                    }
                },
                "lastName": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "SURNAME",
                        "type": "VARCHAR"
                    }
                },
                "depId": {
                    "include": false,
                    "type": "STRING",
                    "mandatory": false,
                    "readOnly": false,
                    "notNull": false,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "DEP_ID",
                        "type": "VARCHAR"
                    }
                },
                "idFriend": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": false,
                    "readOnly": false,
                    "notNull": false,
                    "mapping": {
                        "source": "sourceTable2",
                        "columnName": "ID_FRIEND",
                        "type": "VARCHAR"
                    }
                },
                "extKey2": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": false,
                    "readOnly": false,
                    "notNull": false,
                    "mapping": {
                        "source": "sourceTable2",
                        "columnName": "ID",
                        "type": "VARCHAR"
                    }
                },
                "VAT": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable2",
                        "columnName": "VAT",
                        "type": "VARCHAR"
                    }
                },

                "matricola": {
                    "include": false,
                    "type": "INTEGER",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable2",
                        "columnName": "UPDATED_ON",
                        "type": "INTEGER"
                    }
                },
                "updatedOn": {
                    "include": false,
                    "type": "date",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable2",
                        "columnName": "UPDATED_ON",
                        "type": "DATE"
                    }
                }
            }
        }, {
            "name": "Department",
            "mapping": {
                "sourceTables": [{
                    "name": "sourceTable1",
                    "DATETIMESource": "mysql",
                    "tableName": "DEPARTMENT"
                }]
            },
            "properties": {
                "id": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": false,
                    "readOnly": false,
                    "notNull": false,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "ID",
                        "type": "VARCHAR"
                    }
                },
                "departmentName": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "NAME",
                        "type": "VARCHAR"
                    }
                },
                "location": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "LOCATION",
                        "type": "VARCHAR"
                    }
                },
                "updatedOn": {
                    "include": false,
                    "type": "date",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "UPDATED_ON",
                        "type": "DATE"
                    }
                }
            }
        }, {
            "name": "Location",
            "mapping": {
                "sourceTables": [{
                    "name": "sourceTable1",
                    "DATETIMESource": "mysql",
                    "tableName": "LOCATION"
                }]
            },
            "properties": {
                "idLocation": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": false,
                    "readOnly": false,
                    "notNull": false,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "ID",
                        "type": "VARCHAR"
                    }
                },
                "Name": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "NAME",
                        "type": "VARCHAR"
                    }
                },
                "location": {
                    "include": true,
                    "type": "STRING",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "LOCATION",
                        "type": "VARCHAR"
                    }
                },
                "updatedOn": {
                    "include": false,
                    "type": "date",
                    "mandatory": true,
                    "readOnly": false,
                    "notNull": true,
                    "mapping": {
                        "source": "sourceTable1",
                        "columnName": "UPDATED_ON",
                        "type": "DATE"
                    }
                }
            }
        },

		{
		    "name": "Project",
		    "mapping": {
		        "sourceTables": [{
		            "name": "sourceTable1",
		            "DATETIMESource": "mysql",
		            "tableName": "PROJECT"
		        }]
		    },
		    "properties": {
		        "idProgetto": {
		            "include": true,
		            "type": "STRING",
		            "mandatory": false,
		            "readOnly": false,
		            "notNull": false,
		            "mapping": {
		                "source": "sourceTable1",
		                "columnName": "ID",
		                "type": "VARCHAR"
		            }
		        },
		        "NameProgetto": {
		            "include": true,
		            "type": "STRING",
		            "mandatory": true,
		            "readOnly": false,
		            "notNull": true,
		            "mapping": {
		                "source": "sourceTable1",
		                "columnName": "NAME",
		                "type": "VARCHAR"
		            }
		        },
		        "location": {
		            "include": true,
		            "type": "STRING",
		            "mandatory": true,
		            "readOnly": false,
		            "notNull": true,
		            "mapping": {
		                "source": "sourceTable1",
		                "columnName": "LOCATION",
		                "type": "VARCHAR"
		            }
		        },
		        "updatedOn": {
		            "include": false,
		            "type": "date",
		            "mandatory": true,
		            "readOnly": false,
		            "notNull": true,
		            "mapping": {
		                "source": "sourceTable1",
		                "columnName": "UPDATED_ON",
		                "type": "DATE"
		            }
		        }
		    }
		}, {
		    "name": "Project-Persona",
		    "mapping": {
		        "sourceTables": [{
		            "name": "sourceTable1",
		            "DATETIMESource": "mysql",
		            "tableName": "PROJECT-PERSON"
		        }]
		    },
		    "properties": {
		        "idProgetto": {
		            "include": true,
		            "type": "STRING",
		            "mandatory": false,
		            "readOnly": false,
		            "notNull": false,
		            "mapping": {
		                "source": "sourceTable1",
		                "columnName": "IDProgetto",
		                "type": "VARCHAR"
		            }
		        },
		        "idPersona": {
		            "include": true,
		            "type": "STRING",
		            "mandatory": true,
		            "readOnly": false,
		            "notNull": true,
		            "mapping": {
		                "source": "sourceTable1",
		                "columnName": "IDPersona",
		                "type": "VARCHAR"
		            }
		        },
		        "location": {
		            "include": true,
		            "type": "STRING",
		            "mandatory": true,
		            "readOnly": false,
		            "notNull": true,
		            "mapping": {
		                "source": "sourceTable1",
		                "columnName": "LOCATION",
		                "type": "VARCHAR"
		            }
		        },
		        "updatedOn": {
		            "include": false,
		            "type": "date",
		            "mandatory": true,
		            "readOnly": false,
		            "notNull": true,
		            "mapping": {
		                "source": "sourceTable1",
		                "columnName": "UPDATED_ON",
		                "type": "DATE"
		            }
		        }
		    }
		}
	],
        "edges": [{
            "WorksAt": {
                "mapping": [{
                    "fromTable": "PERSON",
                    "fromColumns": ["ID"],
                    "toTable": "DEPARTMENT",
                    "toColumns": ["ID"],
                    "direction": "direct"
                }],
                "properties": {
                    "since": {
                        "include": true,
                        "type": "date",
                        "mandatory": true,
                        "readOnly": false,
                        "notNull": false
                    }
                }
            }
        },

		{
		    "In": {
		        "mapping": [{
		            "fromTable": "DEPARTMENT",
		            "fromColumns": ["ID"],
		            "toTable": "LOCATION",
		            "toColumns": ["ID"],
		            "direction": "direct"
		        }],
		        "properties": {
		            "since": {
		                "include": true,
		                "type": "date",
		                "mandatory": true,
		                "readOnly": false,
		                "notNull": false
		            }
		        }
		    }
		}, {
		    "LavoraA": {
		        "mapping": [{
		            "fromTable": "PERSON",
		            "fromColumns": ["ID"],
		            "toTable": "PROJECT",
		            "toColumns": ["ID"],
		            "direction": "direct"
		        }],
		        "properties": {
		            "since": {
		                "include": true,
		                "type": "date",
		                "mandatory": true,
		                "readOnly": false,
		                "notNull": false
		            }
		        }
		    }

		}
	]
    };
    //return myObj;
    return newObj;
}