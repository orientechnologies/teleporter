﻿(function () {
    'use strict';

    var serviceId = 'modalService';
    angular.module('app').factory(serviceId, ['$modal', 'common', modalService]);

    function modalService($modal, common) {
        var getLogFn = common.logger.getLogFn;
        var logError = getLogFn(serviceId, 'error');


        return {
            crea: function (size, urlTemplate, item, canWrite) {
                return $modal.open(
                    {
                        templateUrl: urlTemplate,  //'/app/admin/nuovoUser.html',
                      
                        controller: function ($scope, $modalInstance) {
                            $scope.item = item || {};

                            $scope.canWrite = canWrite == undefined ? true : canWrite ;

                            $scope.ok = function (obj) {
                              //  if (form.$valid) {
                                    $modalInstance.close(obj);
                                //}
                                //else {

                                //    logError("i dati inseriti non sono validi");
                                //}
                            };
                            $scope.cancel = function () {
                                $modalInstance.dismiss('cancel');
                            };
                        },
                        size: size
                    }).result;
            }
        }
    }
})();