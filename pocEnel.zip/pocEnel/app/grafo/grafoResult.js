﻿//(function () {
//    'use strict';

var app = angular.module('app');




app.directive('grafoResult', function () {
    // Opens and clsoes the sidebar menu.
    // Usage:
    //  <div data-cc-sidebar>
    // Creates:
    //  <div data-cc-sidebar class="sidebar">
    var directive = {
        link: link,
        restrict: 'A'
    };
    return directive;

    function link($scope, myObj, container, man) {
        container = document.getElementById(container.id);
        $scope.container = container;

        man = $scope.man;
        $scope.$on("redraw", function (event, data) {
            init();
        })

        $scope.color = ['#1682ab', '#FF8800', '#ce7748', '#0a7f60', '#dbb015'];

        $scope.options = {
            nodes: {
                shape: 'dot',
              
                scaling: {
                    min: 10,
                    max: 30
                },
                font: {
                    size: 12,
                    face: 'Tahoma',
                    color: '#3a557a'
                }

            },

            groups: {
                useDefaultGroups: true,
                  V: {

                    color: '#1682ab',
                    shape: 'dot'
                },

                Unitaproduzione: {

                    color: '#1682ab',
                    shape: 'dot'
                },
                Turbinaausiliaria: {
                    color: '#FF8800', // border: '#0e4f67' },
                    shape: 'dot'
                },
                Pompaalimentatore: {
                    color: '#ce7748', // border: '#0e4f67' },
                    shape: 'dot'
                },
                Pompabooster: {
                    color: '#0a7f60', // border: '#0e4f67' },
                    shape: 'dot'
                },
                Generationnotificationevent: {
                    color: '#dbb015',  // border: '#0e4f67' },
                    shape: 'dot'
                }


            },
            "edges": {
                "font": {
                    "size": 14,
                    "color": "#0e4f67"
                },
                "scaling": {
                    "min": 24,
                    "max": 46
                },
                "shadow": {
                    "enabled": false,
                    "size": 0.8,
                    "x": 1,
                    "y": 1
                },
                "smooth": {
                    "forceDirection": "none"
                },
                "physics": false
            },
            manipulation: {
                initiallyActive: false,
                addNode: function (data, callback) {
                    $scope.addNode(data, callback);

                },
                deleteEdge: function (data, callback) {
                    $scope.deleteEdge(data, callback);

                },

                deleteNode: function (data, callback) {

                    $scope.deleteNode(data, callback);
                }

                    , addEdge: function (data, callback) {
                        $scope.addEdge(data, callback);

                    }
            },

            "interaction": {
                hover: true,
                navigationButtons: true,
                multiselect: true

            },

            "physics": {
                "barnesHut": {
                    "avoidOverlap": 1
                },
                "minVelocity": 0.75,
                "solver": "hierarchicalRepulsion"
            }
        }

        if (man == false) {
            $scope.options.manipulation = false;


        }
      

        //    $scope.options.groups = $scope.groups;

        function init() {

            for (var g in $scope.colorGroups) {

                $scope.options.groups[g] = $scope.colorGroups[g];

            }
            var dataTeleporter = $scope.resultGrafo;
            //            dataTeleporter.forEach(function (item) {
            //                var labelItem = '';
            //                for (var i in item) {
            //                    if ((i.indexOf('@') != -1)) {
            //                        labelItem = i.slice(i.indexOf('@') + 1);
            //                        item[labelItem] = item[i];
            //                    }
            //                    if ((i.indexOf('_id') != -1)) {
            //                        labelItem = 'id';
            //                        item[labelItem] = item[i];
            //                    }
            //                    //                        if ((i.indexOf('in') != 0)) {
            //                    //                            labelItem = 'vin';
            //                    //                            item[labelItem] = item[i];
            //                    //                        }
            //                }
            //            });

            var nodes = new vis.DataSet([]);
            var edges = new vis.DataSet([]);
            var arco = {};
            var etichetta;
            dataTeleporter.forEach(function (v) {
                if (v['in'] != undefined && v.out != undefined) {

                    arco = { id: v['@rid'], label: v['@class'], from: v['in'], to: v['out'], arrows: v['@to'] };
                    edges.add(arco);
                }
                else {
                    // etichetta = v.class.substr(0, 7) + "..";
                    nodes.add({ id: v['@rid'], label: v['@rid'], group: v['@class'], title: v['@class'] + "-" + v['@rid'], name: v['@rid'] });
                }

            });



            var data = {
                nodes: nodes,
                edges: edges
            };

            var network = new vis.Network(container, data, $scope.options);
            if (man == false) {
                var toggleManipulation = function (man) {
                    var opt = { manipulation: { enabled: man} };
                    network.setOptions(opt);
                };
            }

            network.on("addEdge", function (params, callback) {
                var edge = params.edges[0];
                //                    $scope.SelectEdge(edge);
                //                    console.log('selectEdge Event:', params);
                //                    network.redraw();
            });


            network.on("deleteNode", function (params) {
                //                    $scope.deleteNode(params);
            });

            network.on("deleteEdge", function (params) {
                //                    $scope.deleteEdge(params);
            });
            network.on("selectNode", function (params) {

                for (var n in dataTeleporter) {

                    if (dataTeleporter[n]['@rid'] == params.nodes[0]) {

                        $scope.$emit("select", dataTeleporter[n]);

                        return false;
                    }
                }

            });

            network.on("select", function (params) {
                //  $scope.$emit("select", params.nodes[0]);

                //                    $scope.Select(params)
            });

            network.on("selectEdge", function (params) {
                //                    if (params.nodes.length == 0) {
                //                        var edge = params.edges[0];
                //                        $scope.SelectEdge(edge, false);
                //                    }
            });

            $scope.network = network;

            $scope.$emit('wait', false);
        }
        init();
    }

});

//})();