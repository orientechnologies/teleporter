﻿(function () {
    'use strict';
    var controllerId = 'querybuilder';

    angular.module('app').controller(controllerId, ['$scope', '$mdSidenav', '$location', '$base64', '$http', 'context', 'common', 'modalService', 'bootstrap.dialog', 'NgTableParams', querybuilder]);

    function querybuilder($scope, $mdSidenav, $location, $base64, $http, context, common, modalService, dialog, NgTableParams) {
        var getLogFn = common.logger.getLogFn;
        var log = getLogFn(controllerId);
        $scope.man = false;
        $scope.trueFalse = [{ label: "Sì", v: true }, { label: "No", v: false}];
        $scope.MatchPattern = { classMatch: null, ListaFunzioni: [{}], ReturnValue: [{}] };
        $scope.listaFunzioni = [];
        $scope.isValid = true;
        $scope.typies = ["string", "date", "numeric", "boolean"];
        $scope.congiunzioni = ["And", "Or"];
        $scope.operatori = [{ id: '1', testo: '=' }, { id: '2', testo: '>=' }, { id: '3', testo: '>' }, { id: '4', testo: '<' }, { id: '5', testo: '<=' }, { id: '6', testo: '!=' },
           { id: '7', testo: 'like'}];

        $scope.tableParams = new NgTableParams({}, { dataset: $scope.risultato });
        $scope.stateQuery = 0;
        activate();
        $scope.intestazioni = [];
        $scope.showGrafo = false;

        /* ****** */


        $scope.toggleLeft = closeToggler('left');
        $scope.openLeft = buildToggler('left');

        function closeToggler(componentId) {
            return function () {
                if ($mdSidenav(componentId).isOpen()) {
                    $mdSidenav(componentId).toggle();
                }
            }
        }


        function buildToggler(componentId) {
            return function () {
                if (!$mdSidenav(componentId).isOpen()) {
                    $mdSidenav(componentId).toggle();
                }
            }
        }

        /**** */
        $scope.init = true;
        $scope.grafoSwitch = function (grafoSwitch) {
            $scope.$emit('wait');
            $scope.stateQuery = 1;
            $scope.esegui(grafoSwitch).then(function (data) {
                if (data)
                    $scope.showGrafo = grafoSwitch;
            });
        }

        $scope.setMode = function (mode) {
            $scope.mode = mode;
        }
        $scope.ClassMatch = null;
        $scope.where = "";
        $scope.$on("select", function (event, nodo) {
            $scope.selected = nodo;
            $scope.toggleLeft();
            $scope.openSelected = true;
            //$scope.$apply();
            $scope.openLeft();
        })

        $scope.$on("getSimpleQuery", function (event, nodo) {
            $scope.componi($scope.ClassMatch, true);
        });


        $scope.listaAlias = [];
        $scope.$on("controllaAlias", function (event, nodo) {
            $scope.controllaAlias(nodo);
        });

        $scope.controllaAlias = function (nodo) {
            $scope.listaAlias.forEach(function (a) {
                if (a == nodo.alias) {
                    $scope.$broadcast("aliasDuplicato", nodo);
                    $scope.isValid = false;
                    return;
                }
                else {
                    nodo.error = "";
                    $scope.isValid = true;
                }
            })

            $scope.listaAlias.push(nodo.alias);
        }

        $scope.$on('cancelEdge', function (event, data) {
            var vertice = data[1];
            var edge = data[0];
            if (vertice.listaFunzioni.length > 0) {
                vertice.listaFunzioni.splice(vertice.listaFunzioni.indexOf(edge), 1);

            }
            if (edge.classTarget != undefined) {
                $scope.listaAlias.splice($scope.listaAlias.indexOf(edge.classTarget.name));
                edge.classTarget.error = '';
                $scope.$broadcast("deleteNodeFromQuery", edge.classTarget)
                //classTarget.alias = ''; 


            }
            $scope.myObj.edges.forEach(function (e) {
                for (var i in e) {
                    if (i == edge.name) {

                        e[i].alias = '';
                        e[i].direction = '';
                    }
                }

            })

            $scope.listaAlias.splice($scope.listaAlias.indexOf(edge.name));
            $scope.$broadcast("deleteEdgeFromQuery", edge);
            edge = null;
        })

        $scope.$on('cancelNode', function (event, node) {

            if (node.name == $scope.ClassMatch.name) {
                $scope.ClassMatch = null;
            }
            var nomeNodo = node.mapping.sourceTables[0].tableName;
            $scope.$broadcast("deleteNodeFromQuery", nomeNodo);
            $scope.listaAlias.splice($scope.listaAlias.indexOf(node.name));
        })

        $scope.colors = ['#1682ab', '#FF8800', '#ce7748', '#0a7f60', '#dbb015'];
        $scope.colorGroups = {};
        $scope.alias = [];
        var num = 0;

        // ** COMPOSIZIONE QUERY **
        $scope.componi = function (nodo, start, grafo) {

            $scope.colorGroups[nodo.name] = { color: $scope.colors[num], shape: 'dot' };
            num += 1;
            if (grafo != true) {
                $scope.stateQuery = 0;
                num = 0;
               // $scope.colorGroups = {};
            }
            if (start) {

                $scope.strResult = "";
                $scope.alias = [];
            }
            if (nodo.alias != undefined && nodo.alias != '') {
                $scope.alias.push(nodo.alias);
            }

            $scope.stateQuery = 0;
            if (start) {
                $scope.where = "";
                $scope.strResult = "";
                $scope.campiResultFunzione = "";
                $scope.where = "MATCH {class:" + nodo.name; // +",";
            }
            else {
                if (nodo != null) {
                    $scope.where += "{class:" + nodo.name; // +" as " + nodo.alias;
                }
            }

            if (nodo.alias != "") {
                $scope.where += ", as :" + nodo.alias;
            }


            if (nodo.condizioniWhere != undefined) {
                if (nodo.condizioniWhere.length > 0) {
                    $scope.where += ", where: (";
                    nodo.condizioniWhere.forEach(function (c) {
                        if (c.tipoValore == 'DATETIME') {
                            //c.valore = new Date(c.valore); 
                            var strDataValore = 'date(' + '"' + c.valore + '"' + ', "yyyy-mm-dd hh:mm:ss")';
                            $scope.where += c.congiunzione + " " + c.campo.chiave + c.operatore + strDataValore;
                            //c.valore = moment(c.valore).format('YYYY-mm-DD hh:mm:ss')
                        }
                        if (c.tipoValore == 'INTEGER') {
                            //c.valore = new Date(c.valore); 
                            // var strDataValore = 'date(' + '"' + c.valore + '"' + ', "yyyy-mm-dd hh:mm:ss")';
                            $scope.where += c.congiunzione + " " + c.campo.chiave + c.operatore + c.valore;
                            //c.valore = moment(c.valore).format('YYYY-mm-DD hh:mm:ss')
                        }
                        if ((c.tipoValore != 'INTEGER') && (c.tipoValore != "DATETIME")) {
                            $scope.where += c.congiunzione + " " + c.campo.chiave + c.operatore + "'" + c.valore + "'";
                        }

                    })
                    $scope.where += ")";
                }
            }

            if (nodo.tipoQuery != undefined && nodo.tipoQuery != 0) {
                var strSimpleQuery = "";
                switch (nodo.tipoQuery) {
                    case 1: // Archi in uscita
                        strSimpleQuery = ".outE(){} Return $elements";
                        break;
                    case 2: // Archi in entrata
                        strSimpleQuery = ".inE(){} Return $elements";
                        break;
                    case 3: // Vertici in uscita
                        strSimpleQuery = ".out(){} Return $elements";
                        break;
                    case 4: // vertici in entrata
                        strSimpleQuery = ".in(){} Return $elements";
                        break;
                }

                $scope.where += "}" + strSimpleQuery;
                $scope.openWhere = true;
                $scope.stateQuery = 0;
                return;

            }

            if (nodo.traversal == true) {
                $scope.where += " while ($depth < " + nodo.depth + ")";
            }
            $scope.where += "}";
            var campiResult = false;
            var strAlias;
            if (nodo.campiResult.length > 0) {

                nodo.campiResult.forEach(function (c) {
                    if (c.isInResult) {
                        campiResult = true;
                        if (c.alias != '' && c.alias != undefined) {
                            strAlias = ' as ' + c.alias;
                        }
                        else {
                            strAlias = '';
                        }
                        if ($scope.strResult.length == 0) {
                            $scope.strResult = nodo.alias + "." + c.nome + strAlias;
                        }
                        else {
                            $scope.strResult += ", " + nodo.alias + "." + c.nome + strAlias;
                        }
                    }
                });

            }
            if (campiResult && start) {

                if ($scope.strResult.indexOf('@rid') != 0) {

                    $scope.strResult += "," + nodo.alias + "." + '@rid';

                } if ($scope.strResult.indexOf('@class') != 0) {

                    $scope.strResult += "," + nodo.alias + "." + '@class';

                }
            }

            var strMatch = "";

            if (nodo.listaFunzioni != undefined) {

                nodo.listaFunzioni.forEach(function (f) {
                    f.campiResultFunzione = "";
                    f.campiResult.forEach(function (c) {
                        if (c.isInResult) {
                            f.hasResult = true
                            if (c.alias != '' && c.alias != undefined) {
                                strAlias = ' as ' + c.alias;
                            }
                            else {
                                strAlias = '';
                            }
                            if (f.campiResult.indexOf(c) == 1) {
                                $scope.campiResultFunzione += f.alias + "." + c.nome + strAlias;
                                $scope.strResult += f.alias + "." + c.nome;
                            }
                            else {
                                $scope.campiResultFunzione += ", " + f.alias + "." + c.nome + strAlias;
                                $scope.strResult += ", " + f.alias + "." + c.nome;
                            }
                        }
                    });

                    if (f.condizioniWhere.length > 0 || f.hasResult || f.alias != '' || f.alias != undefined) {
                        if (f.direzione.indexOf("E") == -1)
                            f.direzione = f.direzione + "E";
                    }
                    if (f.condizioniWhere.length > 0) {
                        $scope.where += strMatch + ".(" + f.direzione + "('" + f.name + "')";
                        if (f.alias != "" && f.alias != undefined) {
                            $scope.where += "{ as: " + f.alias + "}";
                        }
                        $scope.where += ")";
                        $scope.where += "{where : (";
                        f.condizioniWhere.forEach(function (c) {
                            if (c.tipoValore == 'DATETIME') {
                                //c.valore = new Date(c.valore); 
                                var strDataValore = 'date(' + '"' + c.valore + '"' + ', "yyyy-mm-dd hh:mm:ss")';
                                $scope.where += c.congiunzione + " " + c.campo.chiave + c.operatore + strDataValore;
                                //c.valore = moment(c.valore).format('YYYY-mm-DD hh:mm:ss')
                            }
                            if (c.tipoValore == 'INTEGER') {
                                //c.valore = new Date(c.valore); 
                                // var strDataValore = 'date(' + '"' + c.valore + '"' + ', "yyyy-mm-dd hh:mm:ss")';
                                $scope.where += c.congiunzione + " " + c.campo.chiave + c.operatore + c.valore;
                                //c.valore = moment(c.valore).format('YYYY-mm-DD hh:mm:ss')
                            }
                            if ((c.tipoValore != 'INTEGER') && (c.tipoValore != "DATETIME")) {
                                $scope.where += c.congiunzione + " " + c.campo.chiave + c.operatore + "'" + c.valore + "'";
                            }


                        });
                        $scope.where = $scope.where + ")}";
                    }
                    else {
                        $scope.where += strMatch + "." + f.direzione + "('" + f.name + "')";
                        if (f.alias != "" && f.alias != undefined) {
                            $scope.where += "{ as:  " + f.alias + "}";
                        }

                        if (f.condizioniWhere.length > 0 || f.hasResult) {
                            $scope.alias.push(f.alias);
                        }
                    }
                    //  $scope.where += ")";
                    if (f.classTarget != null) {
                        if (f.direzione == "outE") {
                            $scope.where += ".inV()";
                        }
                        if (f.direzione == "inE") {
                            $scope.where += ".outV()";
                        }
                        $scope.componi(f.classTarget, false);
                    }
                    if (start && nodo.listaFunzioni.length > 0) {

                        strMatch = ",{ as:" + nodo.alias + "}";
                    }
                });
            }

            if (start) {

                if ($scope.strResult.length > 0 && !grafo) {
                    $scope.strResult = "Return " + $scope.strResult;
                }
                else {
                    $scope.strResult = " Return $elements";
                }
                $scope.where = $scope.where + $scope.strResult;

            }
            $scope.openWhere = true;
            $scope.stateQuery = 0;
        }

        function levaultimo(str) {
            var len = str.length;
            str = str.substr(0, len - 1);
            return str;
        }

        // ** FINE COMPOSIZIONE QUERY **

        // ** GESTIONE EVENTI SUL GRAFO ** 
        // ** cerco l'arco che collega due vertici, scorrendo nella class match
        $scope.isLinked = function (edges, classA, classB) {
            for (var e in edges) {
                if (edges[e].mapping[0].fromTable == classA.mapping.sourceTables[0].tableName) {
                    if (edges[e].mapping[0].toTable == classB.mapping.sourceTables[0].tableName) {
                        return { edge: e, classA: classA };
                    }
                }
                if (edges[e].mapping[0].toTable == classA.mapping.sourceTables[0].tableName) {
                    if (edges[e].mapping[0].fromTable == classB.mapping.sourceTables[0].tableName) {
                        return { edge: e, classA: classA };
                    }
                }
            }
            if (classA.listaFunzioni != undefined) {
                for (var f in classA.listaFunzioni) {
                    if (classA.listaFunzioni[f].classTarget != undefined) {
                        return $scope.isLinked(edges, classA.listaFunzioni[f].classTarget, classB);
                    }
                }
            }
        }

        $scope.findEdge = function (classA, classB) {
            var edgeFounded = {};
            for (var edges in $scope.myObj.edges) {
                edgeFounded = $scope.isLinked($scope.myObj.edges[edges], classA, classB)
                if (edgeFounded) {
                    return edgeFounded;
                }
            }
            return edgeFounded;
        }

        $scope.selectNode = function (params, isAdd) {
            var find = false;
            var nodoFound;
            $scope.myObj.vertices.forEach(function (v) {
                if (nodoFound == undefined) {
                    for (var sourceTable in v.mapping.sourceTables) {
                        if (v.mapping.sourceTables[sourceTable].tableName == params) {
                            v.campiForCondizione = [];
                            v.campiResult = [];
                            v.inQuery = true;
                            v.alias = v.name  //.substr(0, 1);
                            $scope.controllaAlias(v);
                            for (var key in v.properties) {
                                v.properties[key].rename = key;
                                if (v.properties[key].include) {
                                    v.campiForCondizione.push({ chiave: key, valore: v.properties[key].mapping.columnName, tipo: v.properties[key].type });
                                }
                                v.campiResult.push({ nome: key, isInResult: false });

                            }
                            nodoFound = v;
                        }
                    }
                }
            });
            //se La class Match è ancora undefined il nodo diventa la class match
            if ($scope.ClassMatch == undefined || $scope.ClassMatch.name == "") {
                $scope.ClassMatch = angular.copy(nodoFound);
                $scope.ClassMatch.traversal = false;
                $scope.segnaOggetto($scope.ClassMatch.name);
            }
            else {
                if ($scope.ClassMatch.name != nodoFound.name) {
                    $scope.verticeSelected = angular.copy(nodoFound);
                    // cerco se il nodo selezionato è collegato alla classe Match 
                    var newEdge = $scope.findEdge($scope.ClassMatch, $scope.verticeSelected);
                    // se sono collegati l'arco trovato diventa una funzione e lo aggiungo alle funzioni della ClassMatch
                    if (newEdge != undefined) {
                        setFunzione(newEdge.edge, newEdge.classA, nodoFound);
                        // $scope.SelectEdge(newEdge, true, 'nodo');
                        $scope.segnaOggetto(nodoFound.name);
                    }
                    else {
                        var msg = "Il vertice " + nodoFound.name + " non è collegato con la class  " + $scope.ClassMatch.name + ", si vuole sostituire?"
                        dialog.confirmationDialog("Aggiungi Funzione", msg, "ok", "Annulla").then(function (result) {
                            $scope.$broadcast("deleteAllFromQuery");
                            $scope.ClassMatch = angular.copy(nodoFound);
                            $scope.segnaOggetto(nodoFound.name);

                        });
                    }
                }
                find = true;

            }
            $scope.selected = true;

            if (!$scope.selected) {
                $scope.verticeSelected = null;
                $scope.vsProperties = [];
            }
            if (!(isAdd)) {
                $scope.$apply();
            }
        }

        // ** creo una Funzione 
        function setFunzione(edge, Nodo, classTarget) {
            var Funzione = { direzione: {}, name: "", alias: "", whereCondition: "", condizioniWhere: [], navigationFunction: "", classTarget: null, campiForCondizione: [] };
            var arcotrovato = $scope.findArco(Nodo, edge);
            if (arcotrovato == undefined) {
                $scope.myObj.edges.forEach(function (a) {
                    for (var k in a) {
                        if (k == edge) {
                            Funzione = a[k];
                            Funzione.campiForCondizione = [];
                            Funzione.condizioniWhere = [];
                            Funzione.campiResult = [];
                            Funzione.name = k;
                            Funzione.alias = k; //.substr(0, 1);
                            $scope.controllaAlias(Funzione);
                            Funzione.direzione = getDirezione(a[k], Nodo);

                            //toDo - la direzione può essere o dalla classe target o dalla classe Match .. verificare
                            if (Funzione.direzione == undefined) {
                                Funzione.direzione = getDirezione(a[k], Nodo);
                            }
                            for (var key in Funzione.properties) {
                                Funzione.properties[key].rename = key;
                                Funzione.campiForCondizione.push({ chiave: key, valore: Funzione.properties[key], tipo: Funzione.properties[key].type });
                                Funzione.campiResult.push({ nome: key, isInResult: false });
                            }
                        }
                    }
                });
                if (classTarget != undefined) {
                    Funzione.classTarget = impostaClasseTarget(classTarget, Funzione.classTarget);
                }
                else {
                    Funzione = findClasseTarget(Funzione, Nodo, false);
                }
                if (Nodo != undefined) {
                    if (Nodo.listaFunzioni == undefined) {
                        Nodo.listaFunzioni = [];
                    }
                    Nodo.listaFunzioni.push(Funzione);
                }
            }
            else { // l'arco è già unito 
                if (arcotrovato.classTarget == null) {
                    arcotrovato.classTarget = impostaClasseTarget(classTarget, arcotrovato.classTarget);

                }

            }
        }


        // ** PER LA GESTIONE DEGLI ARCHI
        function getDirezione(arco, classMatch) {

            var tableTo = arco.mapping[0].toTable;
            var tableFrom = arco.mapping[0].fromTable;
            var dir = arco.mapping[0].direction;

            if (classMatch != undefined) {
                switch (dir) {
                    case "direct":
                        for (var t in classMatch.mapping.sourceTables) {
                            if (classMatch.mapping.sourceTables[t].tableName == tableTo)
                                return "in";
                            if (classMatch.mapping.sourceTables[t].tableName == tableFrom)
                                return "out";
                        }
                        break;

                    case "invers":
                        for (var t in classMatch.mapping.sourceTables) {
                            if (classMatch.mapping.sourceTables[t].tableName == tableTo)
                                return "out";
                            if (classMatch.mapping.sourceTables[t].tableName == tableFrom)
                                return "in";
                        }
                        break;
                    default: return "both";
                }
            }
        }


        $scope.findArco = function (vertice, edge) {
            var arco;
            if (vertice != undefined) {
                if (vertice.listaFunzioni != undefined) {
                    vertice.listaFunzioni.forEach(function (f) {

                        if (f.name == edge) {
                            arco = f;
                            return arco;
                        }
                    })
                }
            }
            return arco;
        };

        $scope.segnaOggetto = function (elem) {

            $scope.myObj.vertices.forEach(function (v) {
                if (v.mapping.sourceTables[0].tableName.toUpperCase() == elem.toUpperCase()) {
                    v.InQuery = true;
                    $scope.$emit("segnaQuery", v.mapping.sourceTables[0].tableName);
                    $scope.$broadcast("segnaQuery", v.mapping.sourceTables[0].tableName);
                }
            });
            $scope.myObj.edges.forEach(function (v) {
                for (var edge in v) {
                    if (edge.toUpperCase() == elem.toUpperCase) {
                        $scope.$broadcast("segnaQueryEdge", edge);
                    }
                }
            });
        }

        $scope.SelectEdge = function (edge, isAdd, start) {
            var Funzione = { direzione: {}, name: "", alias: "", whereCondition: "", condizioniWhere: [], navigationFunction: "", classTarget: null, campiForCondizione: [] };
            var classMatch;
            if ($scope.ClassMatch != undefined) {
                if ($scope.ClassMatch.listaFunzioni == undefined) {
                    $scope.ClassMatch.listaFunzioni = [];
                    classMatch = $scope.ClassMatch;
                }

                if ($scope.ClassMatch.listaFunzioni != undefined) {
                    $scope.ClassMatch.listaFunzioni.forEach(function (f) {
                        if (f.classTarget != undefined) {
                            classMatch = f.classTarget;
                            if (f.classTarget.listaFunzioni != undefined) {
                                f.classTarget.listaFunzioni.forEach(function (f1) {
                                    if (f1.classTarget != undefined) {
                                        classMatch = f1.classTarget;
                                        $scope.segnaOggetto(classMatch);
                                    }
                                });
                            }
                        }
                    })
                }
            }
            setFunzione(edge, classMatch);
            $scope.$broadcast('segnaQueryEdge', edge);
            if (!isAdd) {
                $scope.$apply();
            }

        }


        function findClasseTarget(Funzione, classMatch, start) {
            var tableNameTo = Funzione.mapping[0].toTable;
            var tableNameFrom = Funzione.mapping[0].fromTable;

            if (tableNameFrom == tableNameTo) {  // si tratta di ricorsiva
                Funzione.isSelfR = true;
                Funzione.depth = 1;
                // 
                var cm = $scope.ClassMatch;
                var newCampiResult = angular.copy($scope.ClassMatch.campiResult);
                newCampiResult.forEach(function (c) {
                    c.isInResult = false;

                })
                dialog.inputDialog("Livello di profondità", "L'arco selezionato rappresenta una relazione ricorsiva: fino a che livello si vuole selezionare? ", "profondità").then(function (result) {
                    Funzione.depth = result;
                    //  / creo classe target per la ricorsiva
                    Funzione.classTarget = { alias: cm.name, //.substr(0, 1),
                        depth: Funzione.depth,
                        traversal: true,
                        campiForCondizione: cm.campiForCondizione,
                        campiResult: newCampiResult,
                        condizioniWhere: [],
                        listaFunzioni: [],
                        mapping: cm.mapping,
                        name: cm.name,
                        properties: cm.properties
                    };
                    $scope.controllaAlias(Funzione);
                    $scope.segnaOggetto(cm.name);
                    // Funzione.classTarget.condizioniWhere = [{ congiunzione: "", campo: "", operatore: "", valore: ""}];
                })

            }
            else {
                if (classMatch != undefined) {
                    $scope.myObj.vertices.forEach(function (v) {

                        for (var sourceTable in v.mapping.sourceTables) {
                            if (v.mapping.sourceTables[sourceTable].tableName == tableNameTo) {
                                // if (classMatch != undefined) {
                                if ($scope.ClassMatch.mapping.sourceTables[0].tableName != tableNameTo && tableNameTo != classMatch.mapping.sourceTables[0].tableName) {
                                    dialog.confirmationDialog("Aggiungi Funzione", "Collegare il vertice  " + tableNameTo + " ?", "Sì, collega", "No, non collegare").then(function (result) {

                                        Funzione.classTarget = impostaClasseTarget(v, Funzione.classTarget);
                                        $scope.segnaOggetto(tableNameTo);
                                        return Funzione;
                                    });
                                }
                                // }
                            }
                            if (v.mapping.sourceTables[sourceTable].tableName == tableNameFrom) {
                                if ($scope.ClassMatch.mapping.sourceTables[0].tableName != tableNameFrom && tableNameFrom != classMatch.mapping.sourceTables[0].tableName)
                                    dialog.confirmationDialog("Aggiungi funzione", "collegare il vertice  " + tableNameFrom + " ?", "Sì, collega", "No, non collegare").then(function (result) {
                                        Funzione.classTarget = {};

                                        Funzione.classTarget = impostaClasseTarget(v, Funzione.classTarget);
                                        $scope.segnaOggetto(tableNameFrom);
                                        return Funzione;
                                    });
                            }

                        }

                    });
                }
            }
            return Funzione;
        }

        function impostaClasseTarget(source, target) {
            target = angular.copy(source);
            target.condizioniWhere = [];
            target.campiForCondizione = [];
            target.campiResult = [];
            target.traversal = false;
            target.alias = target.name; //.substr(0, 1);
            //  $scope.controllaAlias(target);
            for (var key in source.properties) {
                source.properties[key].rename = key;
                target.campiForCondizione.push({ chiave: key, valore: source.properties[key].mapping.columnName, tipo: source.properties[key].type });
                target.campiResult.push({ nome: key, isInResult: false });
            }

            $scope.selected = true;

            return target;
        }



        //** RECUPERO PROPRETA DEI VERTICI PER REGOLEE DI JOIN **
        function getFromAndTo(tableFromName, tableToName) {
            $scope.tableFromName = tableFromName;
            $scope.tableToName = tableToName;
            $scope.tableFrom = [];
            $scope.tableTo = [];
            $scope.myObj.vertices.forEach(function (v) {
                if (v.mapping.sourceTables[0].tableName == tableFromName) {
                    for (var key in v.properties) {
                        $scope.tableFrom.push({ chiave: key, valore: v.properties[key].mapping.columnName });
                    }
                }
                if (v.mapping.sourceTables[0].tableName == tableToName) {
                    for (var key in v.properties) {
                        $scope.tableTo.push({ chiave: key, valore: v.properties[key].mapping.columnName });
                    }
                }
            });
        }






        $scope.connettiDB = function (result) {

            $scope.testConnection(result);
            $scope.init = false;
        }


        function getObjectForQuery() {
            $scope.$emit("wait", true);
            if (context.dbConfig.url != undefined) {
                context.getSchema().then(function (data) {
                    if (data.STATO != 1) {
                        $scope.message = data.message;
                        // $scope.getObjectForQuery();
                    }
                    else {
                        if (data.DATA != undefined) {
                            $scope.myObj = data.DATA;

                            var container = document.getElementById('mynetwork');
                            $scope.container = container;
                            $scope.$emit("isConnected", true);
                            $scope.$emit("wait", false);
                            //dialog.confirmationDialog("Connessione Configurata", "La connessione è stata configurata con successo ", "ok", "Annulla");
                            log("Coonnessione Valida");
                        }

                    }
                }
            ,
             function (error) {

                 $scope.$emit("isConnected", false);
                 dialog.confirmationDialog("Errore", "Impossibile caricare lo schema del db", "ok", "Annulla");
                 $scope.myObj = null;
             });
            }
            else {
                dialog.confirmationDialog("Connessione assente", "Nessuna connessione ", "ok", "Annulla");
            }

        }

        $scope.openSelected = false;
        $scope.closeOpenSelected = function (isOpen) {
            $scope.openSelected = isOpen;
        }

        $scope.testConnection = function (result) {
            $scope.$emit("wait", true);
            $scope.init = true;
            //            context.testConnection(result).then(function (status) {
            context.getSchema(result).then(function (data) {
                if (data.status > 0) {

                    getObjectForQuery();
                    $scope.init = false;
                }
                else {

                    $scope.$emit("isConnected", false);
                    dialog.confirmationDialog("Errore", "Impossibile effettuare la connessione ", "ok", "Annulla");
                    $scope.$emit("wait", false);
                }

            },
             function (error) {
                 $scope.$emit("wait", false);
                 $scope.$emit("isConnected", false);
                 dialog.confirmationDialog("Errore", "Impossibile effettuare la connessione ", "ok", "Annulla");

             });
        }

        $scope.closeOpenWhere = function (isOpen) {
            $scope.openWhere = isOpen;
        }

        $scope.esporta = function () {
            var blob = new Blob([document.getElementById('exportable').innerHTML], {
                type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=utf-8"

            });
            saveAs(blob, "Report.xls");
        }


        function trasforma(dataresult) {
            var newObj = []

            var elements = {};
            dataresult.forEach(function (e) {
                elements = {};
                var valore;
                for (var i in e) {
                    valore = e[i];
                    // var label = i.slice(i.indexOf('_') + 1)
                    var label = i;
                    elements[label] = valore;
                    if (!_.contains($scope.intestazioni, label)) {
                        if (label != '@type' && label != '@version' && label.substr(0, 3) != 'in_' && label.substr(0, 4) != 'out_')
                            $scope.intestazioni.push(label);
                    }
                }
                //newObj.push(elements);
            })

            dataresult.forEach(function (elem) {
                var newItem = {};
                $scope.intestazioni.forEach(function (intestazione) {
                    if (elem[intestazione] != undefined) {
                        newItem[intestazione] = elem[intestazione];
                    }
                    if (elem[intestazione] == undefined) {
                        newItem[intestazione] = "";
                    }
                })
                newObj.push(newItem);
            })

            return newObj;

        }



        function eseguiQuery(query, url, auth) {
            $scope.$emit("wait", true);
            $scope.intestazioni = [];
            var defer = common.$q.defer();
            var send = url + query;
            var headers;

            headers = { "Authorization": "Basic " + auth };
            $http.get(send, { headers: headers }).then(function (response) {
                if (response.status == 200) {

                    $scope.resultGrafo = response.data.result;
                    context.cacheQuery($scope.ClassMatch);
                    defer.resolve(trasforma(response.data.result));
                    $scope.$emit("wait", false);
                }
                else {
                    defer.resolve(response.statusText);
                    $scope.$emit("wait", false);

                }
            },

             function (error) {
                 $scope.$emit("wait", false);
                 // $scope.$emit("isConnected", false);
                 dialog.confirmationDialog("Errore", error.statusText, "ok", "Annulla");
                 $scope.myObj = null;
             });

            return defer.promise;
        }


        $scope.esegui = function (grafo) {
            // la rendo una promise per gestire meglio i tempi di switch
            var defer = common.$q.defer();
            // se Grafo è true mi faccio restituire tutti gli elementi 
            $scope.componi($scope.ClassMatch, true, grafo);
            if (grafo == undefined) {
                $scope.stateQuery = 0;
            }
            else {

                $scope.stateQuery = 1
            }
            var query = $scope.where;
            var strLimit = " LIMIT 500";
            query = query + strLimit;
            $scope.$emit('attesa', controllerId);

            $scope.url = context.dbConfig.url;
            var auth = $base64.encode(context.dbConfig.user + ':' + context.dbConfig.psw);

            if ($scope.url != undefined) {


                return eseguiQuery(query, $scope.url, auth).then(function (data) {
                    if (grafo == undefined)
                        $scope.openWhere = true;
                    $scope.stateQuery = 1;
                    $scope.risultato = data;
                    $scope.tableParams = new NgTableParams({}, { dataset: data });
                    $scope.cols = [];
                    defer.resolve(true);
                    return true;

                }, function (err) {
                    $scope.stateQuery = 2;
                    $scope.error = err;
                });
            }
            else {
                alert("la connessine al db non è impostata!");
                defer.resolve(false);

            }
            return defer.promise;
        }

        $scope.cancel = function () {
            if ($scope.ClassMatch != null) {
                $scope.ClassMatch.error = '';
                $scope.ClassMatch.listaFunzioni = null;
                $scope.ClassMatch = null;
                context.cacheQuery(null);

            }
            $scope.listaAlias = [];
            $scope.$broadcast("deleteAllFromQuery");
            //            $scope.myObj.vertices.forEach(function (v) {

            //                v.inQuery = false;
            //                $scope.$broadcast("deleteNodeFromQuery", v.name);
            //                //$scope.$emit("redraw", $scope.myObj);
            //            })
            $scope.where = null;
        }

        $scope.setDatePicker = function () {

            $.datepicker.setDefaults($.datepicker.regional['it']);
            $(".data:input").datepicker({ dateFormat: 'dd/mm/YYYY hh:mm:ss' });
            $(".datepicker").datepicker({ dateFormat: 'dd/mm/YYYY hh:mm:ss' });

        }
        function activate() {
            common.activateController([
            //    getObjectForQuery()

            ],
             controllerId)
                .then(function () {
                    $scope.item = context.getdbConfig();
                    $scope.init = !context.isConnected();
                    // *** solo per il mock : 
                    context.setdbConfig();
                    if (context.isConnected()) {
                        //  $scope.myObj = context.getObjMock(); // mock
                        $scope.myObj = context.getObj();
                    }
                    else {
                        var url = "admin";
                        $location.path(url);
                    }

                    $scope.ClassMatch = context.getQueryFromCache();
                    var container = document.getElementById('mynetwork');
                    $scope.container = container;

                });
        }
    }
})();


