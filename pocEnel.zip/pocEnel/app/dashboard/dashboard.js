﻿(function () {
    'use strict';
    var controllerId = 'dashboard';
    angular.module('app').controller(controllerId, ['common', '$location', 'datacontext', 'authService', dashboard]);

    function dashboard(common, $location, datacontext, authService) {
        var getLogFn = common.logger.getLogFn;
        var log = getLogFn(controllerId);

        var vm = this;
        vm.news = {
            title: 'Enel',
            description: 'POC'
        };


        vm.url = window.location.pathname;
   

        vm.gotoDirection = function (incentivo, canWrite) {

            $location.path( '/admin');


        }

     

        vm.messageCount = 0;
        vm.title = 'Dashboard';

        activate();

       

        function activate() {
            var promises = [];
            common.activateController(promises, controllerId)
                .then(function () { });
        }
    }
})();