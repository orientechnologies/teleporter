﻿
angular.module('app').factory('authService', ['datacontext', 'context', '$route', 'common', '$window', authService]);

function authService(datacontext, context, $route, common, $window) {

    var authService = {};

    var $q = common.$q;
    authService.getUser = function () {

        var user = JSON.parse($window.utente);
        return user;
    }

    authService.login = function () {

        var user = JSON.parse($window.utente);
        return common.$q.when(user);


        var defer = common.$q.defer();
      //  var user = context.getUtente();
        if (user) {
            defer.resolve(user);
            return defer.promise;
        }
        else {

            datacontext.getUser('api/User').then(function (data) {
                context.createUtente(data);
                if (!data.esito) {
                    common.logger.logError(data.messaggioErrore, undefined, undefined, true);
                }
                else {
                    defer.resolve(data);
                }

            }, function (error) {


                // common.logger.logError(error, undefined, undefined, true);

            })
            //.error(function () {
            //    defer.reject('Errore generico');
            //});
            return defer.promise;
        }
    };


    authService.setWrite = function (canWrite) {

        context.setWrite(canWrite);
    }

   
    authService.getWrite = function () {
        dir = context.getIncentivo()
        var user = JSON.parse($window.utente);
        var canWrite = false;
        if (user) {
             angular.forEach(user.impianti, function (incentivo) {
                 if (incentivo.descrizione == dir) {
                     if (incentivo.canWrite) {
                         canWrite = true;
                         return;
                     }
                     else {
                         canWrite = false;
                         return;
                         
                     }
                  

                }

            });
        }
        return canWrite;
    };



    authService.getCategoriaById = function (id) {
        var filtroModel = { incentivo: authService.getIncentivo(), utente: authService.getUtente() };
        var categoria = {};
        var categorie = [];
        datacontext.getItemsByFilter('api/Categoria/incentivo', filtroModel).then(function (data) {
            categorie = data;

            angular.forEach(categorie, function (c) {
                if (c.id == id) {
                    categoria = c;
                    return c;
                }

            });
            //  return categoria;

        }, function (err) {
            common.logger.logError(err.Message, undefined, undefined, true);
        });

        return categoria;



    }




    authService.setIncentivo = function (incentivo) {

        context.setIncentivo(incentivo);

    }

    authService.getIncentivo = function () {
        if (context.getIncentivo() == undefined) {
            if ($route.current.$$route.title != 'dashboard') {
                var dir = $route.current.params.incentivo
            }
            //var dir = $route.current.$$route.sezione;
            context.setIncentivo(dir);
        }

        return context.getIncentivo();

    }

    authService.getUtente = function () {
        var user = JSON.parse($window.utente);
        return user;


    };

    authService.isAuthenticated = function () {
        return !!context.userId;
    };

    authService.isAuthorized = function (authorizedRoles) {
        if (!angular.isArray(authorizedRoles)) {
            authorizedRoles = [authorizedRoles];
        }
        return (authService.isAuthenticated() &&
          authorizedRoles.indexOf(context.userRole) !== -1);
    };

    return authService;
}

