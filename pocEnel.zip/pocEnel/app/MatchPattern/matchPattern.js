﻿// ** per il datepicker
var app = angular.module('app');
app.directive("jqdatepicker", function () {
    return {
        scope: {
            condizione: "="
        },
        restrict: 'A',
        require: 'ngModel',
        link: function (scope, element, attrs, ngModelCtrl) {
            element.datetimepicker({
//                dateFormat: 'yyyy-mm-dd',
//                formatDate : 'yyyy-mm-dd',
//                timeFormat: 'hh:mm:ss',
                 format : "Y-m-d H:m:s",

                onSelect: function (date) {
                    scope.date = date;
                    var c = scope.condizione;
                    scope.condizione.valore = date;
                    scope.$apply();
                    scope.$emit("data", [date, scope.condizione])
                }
            });
        }
    };
});


app.directive("classMatch", function ($compile, $http, modalService) {

    return {
        restrict: "E",
        scope: {
            vertice: '=', ischild: '=', operatori: '=', congiunzioni: '='


        },
        templateUrl: 'app/MatchPattern/queryVerticeTpl.html',

        compile: function (tElement, tAttr) {

            var ischild = tAttr['ischild'];
            var contents = tElement.contents().remove();

            var compiledContents;

            return function (scope, iElement, iAttr) {
                scope.optionsQuery = [{ id: 0, valore: "Pattern Match" }, { id: 1, valore: "Archi in Uscita" }, { id: 2, valore: "Archi in entrata" }, { id: 3, valore: "Vertici in Uscita" }, { id: 4, valore: "Vertici in Entrata"}];
                scope.openResult = function (nodo) {

                    var urlTemplate = '/pocEnel/app/queryBuilder/queryReturnModalTpl.html';
                    var modal = modalService.crea('40', urlTemplate, nodo, true);
                    modal.then(function (result) {
                        nodo.campiResult = result.campiResult;

                    });
                };

                // *** funzioni per le condizioni di where
                scope.aggiungiCondizioneWhere = function (nodo) {
                    if (nodo.condizioniWhere == undefined) {
                        nodo.condizioniWhere = [];
                    }
                    if (nodo.condizioniWhere.length > 0)
                        nodo.condizioniWhere.push({ congiunzione: "And", "campo": "", "operatore": "", "valore": "" });
                    else
                        nodo.condizioniWhere.push({ congiunzione: "", "campo": "", "operatore": "", "valore": "" });
                }



                scope.controllaAlias = function (nodo) {
                    var alias = nodo.alias;
                    scope.$emit("controllaAlias", nodo);


                }
                scope.eliminaCondizione = function (condizione) {

                    scope.vertice.condizioniWhere.splice(scope.vertice.condizioniWhere.indexOf(condizione), 1);
                }

                scope.validaCondizione = function (condizione, questo) {
                    if (condizione.campo.tipo == 'int') {
                        // condizione.valore = parseInt(condizione.valore);
                        if (isNaN(parseInt(condizione.valore))) {
                            condizione.errore = "Inserire un valore numerico";
                        }
                        else {
                            condizione.errore = null;
                        }
                    }

                }

                scope.chgCampoCondition = function (nodo, condizione, campo) {
                    var c = condizione;
                    condizione.tipoValore = condizione.campo.tipo;
                    condizione.valore = "";
                    condizione.operatore = "";
                    condizione.errore = "";
                }

                scope.setDatePicker = function () {

                    $.datepicker.setDefaults($.datepicker.regional['it']);
                    $(".data:input").datepicker({ dateFormat: 'dd/mm/YYYY hh:mm:ss' });
                    $(".datepicker").datepicker({ dateFormat: 'dd/mm/YYYY hh:mm:ss' });

                }



                scope.checkTipoQuery = function (node) {

                    if (node.tipoQuery != 0) {
                        scope.$emit("getSimpleQuery", node);
                    }

                }


                scope.cancelNode = function (node) {
                    node.archiInUscita = null;
                    node.verticiInUscita = null;
                    node.error = "";
                    scope.$emit('cancelNode', node);
                    node = null;
                    scope.vertice = null;
                }

                scope.$on("aliasDuplicato", function (event, nodo) {
                    nodo.alias = "";
                    nodo.error = "Alias già presente";

                })
                scope.$on("data", function (event, dt, condizione) {

                })
                //                scope.$on('cancelEdge', function (event, edge) {
                //                    var nodo = scope.vertice;
                //                    nodo.listaFunzioni.splice(nodo.listaFunzioni.indexOf(edge), 1);
                //                    

                //                })

                if (!compiledContents) {
                    compiledContents = $compile(contents);
                }
                compiledContents(scope, function (clone, scope) {
                    iElement.append(clone);

                });
            }
        }

    }
});



app.directive("edgePattern", function ($compile, $http, modalService) {

    return {
        restrict: "E",
        scope: {
            edge: '=', ischild: '=', operatori: '=', congiunzioni: '=', vertice: '='
        },
        templateUrl: 'app/MatchPattern/queryEdgeTpl.html',

        compile: function (tElement, tAttr) {

            var ischild = tAttr['ischild'];
            var contents = tElement.contents().remove();
            var compiledContents;

            return function (scope, iElement, iAttr) {

                var t = scope.vertice; 
                scope.openResult = function (nodo) {

                    var urlTemplate = '/pocEnel/app/queryBuilder/queryReturnModalTpl.html';
                    var modal = modalService.crea('40', urlTemplate, nodo, true);
                    modal.then(function (result) {
                        nodo.campiResult = result.campiResult;

                    },
                        function (error) {
                            // log(error);
                        }
                     );
                };

                scope.chgCampoCondition = function (nodo, condizione, campo) {
                    var c = condizione;
                }


                scope.controllaAlias = function (edge) {
                    var alias = edge.alias;
                    scope.$emit("controllaAlias", edge);
                }
                scope.$on("aliasDuplicato", function (event, edge) {
                    edge.alias = "";
                    edge.error = "Alias già presente";

                })

                scope.cancelEdge = function (edge) {
                    edge.direzione = '';
                    edge.alias = '';
                    edge.error = '';
                    scope.$emit('cancelEdge', [edge, scope.vertice] );
                    edge = null;
                }

                scope.aggiungiCondizioneWhere = function (edge) {
                    if (edge.condizioniWhere.length > 0)
                        edge.condizioniWhere.push({ congiunzione: "And", "campo": "", "operatore": "", "valore": "" });
                    else
                        edge.condizioniWhere.push({ congiunzione: "", "campo": "", "operatore": "", "valore": "" });
                }

                scope.eliminaCondizione = function (condizione) {

                    scope.edge.condizioniWhere.splice(scope.edge.condizioniWhere.indexOf(condizione), 1);

                }

                if (!compiledContents) {
                    compiledContents = $compile(contents);
                }
                compiledContents(scope, function (clone, scope) {
                    iElement.append(clone);

                });
            }
        }

    }
});

