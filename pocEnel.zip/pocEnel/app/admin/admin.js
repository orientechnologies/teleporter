﻿(function () {
    'use strict';
    var controllerId = 'admin';

    angular.module('app').controller(controllerId, ['$scope', 'context', 'common', 'modalService', 'bootstrap.dialog', '$timeout', 'modalService', '$http', admin]);

    function admin($scope, context, common, modal, dialog, $timeout, modalService, $http) {
        var getLogFn = common.logger.getLogFn;
        var log = getLogFn(controllerId);
        $scope.trueFalse = [{ label: "Sì", v: true }, { label: "No", v: false}];
        $scope.typies = ["STRING", "DATETIME", "INTEGER", "BOOLEAN", "FLOAT"];
        $scope.tipoRelazione = ['1-n', 'n-n'];
        $scope.tipiAggregazione = ["equality", "aggregation-edge"];
        $scope.posizioniPerJoin = ['fromColumns', 'toColumns', 'properties'];
        $scope.directions = ['direct', 'inverse'];
        $scope.man = true;
        $scope.init = false;
        $scope.drivers = [];
        $scope.openWhere = false;
        $scope.isValidTP = false;
        activate();

        //$scope.selectAll = false; 
        $scope.setMode = function (mode) {
            $scope.mode = mode;
        }
        $scope.unToggleAll = function (properties) {
            for (var p in properties) {
                properties[p].include = false;
            }
        };

        $scope.toggleAll = function (properties) {

            for (var p in properties) {

                properties[p].include = true;
            }

        };
        $scope.$on('openTerminal', function () {
            //  var terminal = $('#terminal');
            //   terminal.scrollTop = terminal[0].scrollHeight;
            $('#terminal').animate({
                scrollTop: $('#terminal').get(0).scrollHeight
            }, 2000);
        })


        var network = {};
        var dataTeleporter = {};

        // ** GESTIONE EVENTI SUL GRAFO ** 
        $scope.Select = function (params) {
            $scope.myObj.vertices.forEach(function (v) {
                for (var sourceTable in v.mapping.sourceTables[0]) {
                    if (sourceTable.tableName == params.nodes[0]) {
                        $scope.verticeSelected = v;
                        for (var key in v.properties) {
                            v.properties[key].rename = key;
                        }
                        $scope.vsProperties = v.properties;
                        $scope.selected = true;
                    }
                }
            })

            if (!$scope.selected) {
                $scope.verticeSelected = null;
                $scope.vsProperties = [];
            }

            $scope.$apply();
        }

        $scope.selectNode = function (params, isAdd) {
            $scope.nomeNodo = params;
            $scope.myObj.vertices.forEach(function (v) {
                for (var sourceTable in v.mapping.sourceTables) {
                    if (v.mapping.sourceTables[sourceTable].tableName == params) {
                        $scope.verticeSelected = v;
                        for (var key in v.properties) {
                            v.properties[key].rename = key;
                        }
                        $scope.vsProperties = v.properties;
                        $scope.selected = true;
                    }
                }
            })
            if (!$scope.selected) {
                $scope.verticeSelected = null;
                $scope.vsProperties = [];
            }
            else {
                $scope.setMode("Nodo");
            }

            if (!(isAdd)) {
                $scope.$apply();
            }
        }

        $scope.deleteEdge = function (data, callback) {
            var edge = data.edges[0];
            dialog.deleteDialog(edge, edge, "Sicuro di volere eliminare " + edge).then(function (result) {
                $scope.myObj.edges.splice($scope.myObj.edges.indexOf(edge), 1);
                callback(data);
                $scope.edgeSelected = null;
                $scope.mode = null;
            });
        }
        $scope.addEdge = function (data, callback) {
            dialog.inputDialog("Nome Arco", "Nome", "Nome").then(function (result) {
                var edge = {
                    name: result,
                    mapping: [{
                        fromTable: data.from,
                        toTable: data.to,
                        fromColumns: [""],
                        toColumns: [""],
                        direction: 'direct'
                    }],
                    relation: false,
                    properties: {}
                }

                data.id = result;
                data.label = result;
                data.arrows = edge.mapping[0].direction == 'direct' ? 'to' : edge.mapping[0].direction == 'inverse' ? 'from' : 'both';
                var i = $scope.myObj.edges.push({});
                $scope.myObj.edges[i - 1][result] = { mapping: edge.mapping, properties: edge.properties };
                callback(data);
                $scope.SelectEdge(result, true);
            });
        }
        $scope.SelectEdge = function (edge, isAdd) {
            var edges = $scope.myObj.edges;
            edges.forEach(function (e) {
                for (var k in e) {
                    if (k == edge) {
                        $scope.edgeSelected = e[k];
                        $scope.edgeSelected.name = k;
                        $scope.selectedEdge = true;
                        var e = $scope.edgeSelected
                        getFromAndTo(e.mapping[0].fromTable, e.mapping[0].toTable);
                    }
                }
            });

            if (!$scope.selectedEdge) {
                $scope.selectedEdge = false;
                $scope.edgeSelected = {};
                return;
            }
            $scope.setMode("Arco");
            if (!isAdd) {
                $scope.$apply();
            }
        }

        $scope.deleteNode = function (data, callback) {
            var node = data.nodes[0];
            dialog.deleteDialog(node, node, "Sicuro di volere eliminare " + node).then(function (result) {
                delete $scope.myObj.vertices[node];
                callback(data);

            });
        }
        // *** funzione aggregazione ** 
        $scope.aggregationStart = function (params) {
            $scope.nomeNodoStart = params.nodes[0];
            $scope.nomeNodoEnd = params.nodes[1]
            if ($scope.nomeNodoStart != undefined) {
                if ($scope.nomeNodoEnd == undefined) {
                    dialog.confirmationDialog("Aggregazione", "Selezionare il nodo ad aggregare con un doppio click", "ok", "Annulla").then(function (result) {

                    });
                }
                else {
                    dialog.confirmationDialog("Aggregazione", "Si vogliono aggregare i nodi " + $scope.nomeNodoStart + " e " + $scope.nomeNodoEnd + "?", "ok", "Annulla").then(function (result) {
                        $scope.aggregationFunction();
                    });
                }
            }
        }


        $scope.changeAggregationType = function (nodo) {
            // nodo.mapping.aggregationFunction 
            // toDo : implementare altre funzioni di aggragazione
        }

        $scope.aggiungiCondizioneAggregazione = function () {
            $scope.condizioniAggregazione.push({ from: "", to: "" });
        }

        // lavora su un array di appoggio per le colonne di aggregazione e poi lo passa alla proprietà columns del nodo
        $scope.chgFromColumnsAggregation = function (elem, condizione, valore) {
            var chk = $scope.condizioniAggregazione;
        }

        // Per gli archi di join
        $scope.chgToColumnsAggregation = function (elem, condizione, valore) {
            $scope.condizioniAggregazione.forEach(function (c) {
                if (c.from != "" && c.to != "") {
                    elem.mapping[0].joinTable.fromColumns.push(c.from);
                    elem.mapping[0].joinTable.ToColumns.push(c.to);
                }
            });
        }

        $scope.chgToColumnsCondition = function (elem, condizione, valore) {
            var columns = [];
            $scope.condizioniAggregazione.forEach(function (c) {
                if (c.from != "" && c.to != "") {
                    columns.push(c.from);
                    columns.push(c.to);
                }
            });
            elem.columns = columns
        }

        $scope.chgFromColumnsCondition = function (condizione, valore) {
            var chk = $scope.condizioniAggregazione;
        }
        $scope.aggregationFunction = function () {
            var nomeNodoStart = $scope.nomeNodoStart;
            var nomeNodoEnd = $scope.nomeNodoEnd;
            $scope.myObj.vertices.forEach(function (v) {
                if (v.mapping.sourceTables[0].tableName == nomeNodoStart) {
                    $scope.nodoStart = v;
                    $scope.vsPropertiesStart = v.properties;
                }
                if (v.mapping.sourceTables[0].tableName == nomeNodoEnd) {
                    $scope.nodoEnd = v;
                    $scope.vsPropertiesEnd = v.properties;
                }
            });
            $scope.edgeSelected = null;
            $scope.condizioniAggregazione = [{ from: "", to: ""}];
            getFromAndTo(nomeNodoStart, nomeNodoEnd);
            $scope.setMode("Aggregazione");
            $scope.nodoAggregato = {
                "name": $scope.nomeNodoStart,
                "mapping": {
                    "sourceTables": [
                            {
                                "name": $scope.nodoStart.mapping.sourceTables[0].name,
                                "dataSource": $scope.nodoStart.mapping.sourceTables[0].dataSource,
                                "tableName": $scope.nodoStart.mapping.sourceTables[0].tableName,
                                "aggregationColumns": []
                            },
                             {
                                 "name": $scope.nodoEnd.mapping.sourceTables[0].name,
                                 "dataSource": $scope.nodoEnd.mapping.sourceTables[0].dataSource,
                                 "tableName": $scope.nodoEnd.mapping.sourceTables[0].tableName,
                                 "aggregationColumns": []
                             },

                        ],
                    "aggregationFunction": "equality"
                },
                "properties":
                    {
                        "Properties1": {
                            "include": true,
                            "type": "string",
                            "mandatory": false,
                            "readOnly": false,
                            "notNull": false,
                            "rename": "Properties1",
                            "mapping": {
                                "source": "",
                                "columnName": "Properties1",
                                "type": ""
                            }
                        }
                    }
            }
        }


        $scope.salvaAggregazione = function (node) {
            node.properties = _.extend(node.properties, $scope.vsPropertiesStart);
            node.properties = _.extend(node.properties, $scope.vsPropertiesEnd);
            $scope.condizioniAggregazione.forEach(function (c) {
                node.mapping.sourceTables[0].aggregationColumns.push(c.from);
                node.mapping.sourceTables[1].aggregationColumns.push(c.to);

            })

            var index = $scope.myObj.vertices.indexOf($scope.nodoStart);
            $scope.$broadcast("removeNode", $scope.nodoStart.mapping.sourceTables[0].tableName);
            $scope.myObj.vertices.splice(index, 1);
            index = $scope.myObj.vertices.indexOf($scope.nodoEnd)
            $scope.$broadcast("removeNode", $scope.nodoEnd.mapping.sourceTables[0].tableName);
            $scope.myObj.vertices.splice(index, 1);
            $scope.myObj.vertices.push(node);

            $scope.$broadcast("addNode", node);
            for (var item in $scope.myObj.edges[0]) {
                if ($scope.myObj.edges[0][item].mapping[0].fromTable == $scope.nomeNodoStart || $scope.myObj.edges[0][item].mapping[0].fromTable == $scope.nomeNodoEnd) {
                    $scope.myObj.edges[0][item].mapping[0].fromTable = node.mapping.sourceTables[0].tableName;
                }
                if ($scope.myObj.edges[0][item].mapping[0].toTable == $scope.nomeNodoStart || $scope.myObj.edges[0][item].mapping[0].toTable == $scope.nomeNodoEnd) {
                    $scope.myObj.edges[0][item].mapping[0].toTable = node.mapping.sourceTables[0].tableName;

                }
            }
        }


        $scope.renameNode = function (node) {
            dialog.inputDialog("Rinomina", "Nome", "Nome").then(function (result) {
                node.name = result;
                $timeout(function () {
                    $scope.$broadcast("updateNodo", node);
                }, 100);
            })
        }

        $scope.renameArco = function (data) {

            dialog.inputDialog("Nome Arco", "Nome", "Nome").then(function (result) {
                var arco = {};
                $scope.myObj.edges.forEach(function (index) {
                    for (var k in index) {
                        if (k == data.name) {
                            index[result] = { mapping: data.mapping, properties: data.properties };
                            arco = index[result];
                            delete index[data.name];
                        }
                    }
                });
                $scope.$broadcast("renameEdge", [data.name, result]);
                $scope.SelectEdge(result, true);

            })
        }




        $scope.changeDirection = function (edge) {
            $scope.$broadcast("updateArco", edge)
        }

        $scope.chosePosizione = function (edge, colonna) {
            var posizione = colonna.posizione;
            switch (posizione) {
                case 'fromColumns':
                    edge.mapping[0].joinTable.fromColumns.push(colonna.valore.mapping.columnName);
                    break;
                case 'toColumns':
                    edge.mapping[0].joinTable.toColumns.push(colonna.valore.mapping.columnName);
                    break;
                case 'properties':
                    edge.properties[colonna.valore.mapping.columnName] = colonna.valore;
                    break;
            }
        }

        $scope.choseTable = function (edge, jTable) {
            edge.colonneJoinTable = [];
            $scope.myObj.vertices.forEach(function (nodo) {
                nodo.mapping.sourceTables.forEach(function (st) {
                    if (st.tableName == jTable) {
                        for (var k in nodo.properties) {
                            edge.colonneJoinTable.push({ name: nodo.properties[k].rename, valore: nodo.properties[k], posizione: '' });
                        }
                    }

                });
            });
        }

        $scope.changeRelation = function (arco) {
            if (arco.relation) {
                //arco.mapping[0].direction = 'both';
                arco.mapping[0].joinTable = {
                    tableName: '',
                    fromColumns: [],
                    toColumns: []
                }
            }

            $scope.nodi = [];
            $scope.myObj.vertices.forEach(function (nodo) {
                if (nodo.mapping.sourceTables[0].tableName != arco.mapping[0].fromTable && nodo.mapping.sourceTables[0].tableName != arco.mapping[0].toTable) {
                    $scope.nodi.push({ nome: nodo.name, nomeTabella: nodo.mapping.sourceTables[0].tableName });
                }

            })
            arco.colonneJoinTable = [];
            $scope.$broadcast("updateArco", arco)
        }

        $scope.eliminaProperty = function (elem, prop) {
            dialog.confirmationDialog("Eliminazione proprietà", "Si vuole eliminare la proprietà " + prop.rename, "ok", "Annulla").then(function (result) {
                delete elem.properties[prop.rename];
            });

        }

        $scope.selectPropertyEdge = function (edge, prop) {
            var item = {};
            if (prop != undefined) {
                item = {
                    "type": prop.type,
                    "mandatory": prop.mandatrory,
                    "readOnly": prop.readOnly,
                    "notNull": prop.notNull,
                    "rename": prop.rename
                };

            }
            item.typies = $scope.typies;
            var urlTemplate = '/pocEnel/app/admin/propertiesEdgeTemplate.html';
            var modal = modalService.crea('40', urlTemplate, item, true);
            modal.then(function (result) {
                result.type = result.type.toUpperCase();
                result[result.rename] = null;
                edge.properties[result.rename] = result;
            },
                        function (error) {
                            log(error);
                        });

        }

        $scope.confermaArco = function (edge) {
            if (edge.mapping[0].joinTable != undefined && edge.mapping[0].joinTable.tableName != '') {
                var nometabella = edge.mapping[0].joinTable.tableName;
                var node;
                $scope.myObj.vertices.forEach(function (n) {
                    if (n.mapping.sourceTables[0].tableName == nometabella)
                        node = n;

                })
                $scope.myObj.vertices.splice($scope.myObj.vertices.indexOf(node), 1);
                $scope.$emit("removeNode", nometabella);
                $scope.$emit("updateArco", edge);

            }
        }

        $scope.addNode = function (data, callback) {
            dialog.inputDialog("Nome Node", "Nome", "Nome").then(function (result) {
                data.id = result;
                data.label = result;
                var Node = {
                    "name": result,
                    "mapping": {
                        "sourceTables": [
                            {
                                "name": "",
                                "dataSource": "",
                                "tableName": result
                            }
                        ]
                    },
                    "properties":
                         {
                             "Properties1": {
                                 "include": true,
                                 "type": "string",
                                 "mandatory": false,
                                 "readOnly": false,
                                 "notNull": false,
                                 "rename": "Properties1",
                                 "mapping": {
                                     "source": "",
                                     "columnName": "Properties1",
                                     "type": ""
                                 }
                             }
                         }
                }
                $scope.myObj.vertices.push(Node);
                callback(data);
                $scope.selectNode(result, true);
            });
        }

        //** RECUPERO PROPRETA DEI VERTICI PER REGOLEE DI JOIN **
        function getFromAndTo(tableFromName, tableToName) {
            $scope.tableFromName = tableFromName;
            $scope.tableToName = tableToName;
            $scope.tableFrom = [];
            $scope.tableTo = [];
            $scope.myObj.vertices.forEach(function (v) {
                if (v.mapping.sourceTables[0].tableName == tableFromName) {
                    for (var key in v.properties) {
                        if (v.properties[key].include)
                            $scope.tableFrom.push({ chiave: key, valore: v.properties[key].mapping.columnName });
                    }
                }
                if (v.mapping.sourceTables[0].tableName == tableToName) {
                    for (var key in v.properties) {
                        if (v.properties[key].include)
                            $scope.tableTo.push({ chiave: key, valore: v.properties[key].mapping.columnName });
                    }
                }
            });
        }

        //** GESTIONE PROPRIETA DI UN VERTICE 


        $scope.selectPropertyNode = function (edge, prop) {
            var item = {};
            if (prop != undefined) {
                item = {
                    "include": true,
                    "type": prop.type,
                    "mandatory": prop.mandatrory,
                    "readOnly": prop.readOnly,
                    "notNull": prop.notNull,
                    "rename": prop.rename,
                    "mapping": prop.mapping
                };

            }
            item.typies = $scope.typies;
            var urlTemplate = '/pocEnel/app/admin/propertiesEdgeTemplate.html';
            var modal = modalService.crea('40', urlTemplate, item, true);
            modal.then(function (result) {
                result.type = result.type.toUpperCase();
                prop = result;
                delete result[result.rename];
                //        delete result["typies"];
                edge.properties[result.rename] = result;

            },
                        function (error) {
                            log(error);
                        });

        }




        $scope.aggiungiProprieta = function (v) {

            // calcolo della ultima posizione  e assegno ordinalPosition
            $scope.chckLastPosition(v); 
            var item = {

                "include": true,
                "type": "STRING",
                "ordinalPosition" : v.lastPosition + 1, 
                "mandatory": false,
                "readOnly": false,
                "notNull": false,
                "mapping": {
                    "source": '',
                    "columnName": "",
                    "type": ""
                }
            };
            item.typies = $scope.typies;
            var urlTemplate = '/pocEnel/app/admin/propertiesNodeTemplate.html';
            var modal = modalService.crea('40', urlTemplate, item, true);
            modal.then(function (result) {
                result.type = result.type.toUpperCase();
                if (result.mapping != undefined) {
                    if (result.mapping.source == '') {
                        delete result["mapping"];
                    }
                }
                v.properties[result.rename] = result;

            },
                        function (error) {
                            // log(error);
                        }
                     );
        }


        $scope.chckLastPosition = function (vertice) {
            var props = vertice.properties;
            var app = 0;
            for (var p in props) {
                if (props[p]["ordinalPosition"] >= app) {
                    app = props[p]["ordinalPosition"];
                }
            }
            vertice.lastPosition = app; 
        }

        $scope.aggiungiProprieta1 = function (v) {


            $scope.myObj.vertices.forEach(function (item) {
                if (item.name == v.name) {
                    $scope.verticeSelected = v;
                    $scope.vsProperties = v.properties;
                    $scope.vsProperties[""] = {
                        "include": true,
                        //"ordinalPosition",
                        "type": "string",
                        "mandatory": false,
                        "readOnly": false,
                        "notNull": false,
                        "mapping": {
                            "source": v.mapping.sourceTables[0].tableName,
                            "columnName": "",
                            "type": "VARCHAR"
                        }
                    };
                    item = v;
                }
            })
        }
        $scope.isValid = false;

        // prima di sincronizzare verifica le eventuali proprietà rinominate
        $scope.verificaOggetto = function () {
            $scope.myObj.vertices.forEach(function (v) {
                for (var p in v.properties) {
                    $scope.changeName(v, p, v.properties[p].rename);
                    if (v.properties[p].mapping != undefined) {
                        if (v.properties[p].mapping.source == '') {
                            delete result["mapping"];
                        }
                    }
                    if (v.properties[p]["typies"])
                        delete v.properties[p]["typies"];
                }

            });
            $scope.isValid = true;
            //  $scope.closeOpenWhere(true);
        }

        // ** RINOMINA PROPRIETA' --- SCATTA SULL'ON-CHANGE
        $scope.changeName = function (vertice, prop, name) {
            var newProperties = {};
            if (vertice.properties[prop].rename != prop) {
                newProperties = vertice.properties[prop];
                delete vertice.properties[prop];
                vertice.properties[name] = newProperties;
            }
            //            for (var k in vertice.properties) {
            //                if (vertice.properties[k].rename != k) {
            //                    newProperties = vertice.properties[k];
            //                    delete vertice.properties[k];
            //                    vertice.properties[name] = newProperties;
            //                }
            //            }
        }


        //** GESTIONE PROPRIETA DI UN ARCO 
        $scope.aggiungiProprietaArco = function (v) {
            for (var item in $scope.myObj.edges[0]) {
                if (item = v.name) {
                    $scope.myObj.edges[0][item].properties["nserire il nome"] = {
                        "include": true,
                        "type": "STRING",
                        "mandatory": true,
                        "readOnly": false,
                        "notNull": false
                    }
                }
            }
        }

        $scope.aggiungiJoinColumn = function (edge) {
            if (edge.mapping[0].joinTable != undefined) {
                edge.mapping[0].joinTable.fromColumns.push('');
                edge.mapping[0].joinTable.toColumns.push('');
            }
        }

        $scope.eliminaCondizioneAggregazione = function (elem, indice) {
            dialog.deleteDialog(elem, elem, "Sicuro di volere eliminare la condizione?").then(function (result) {
                elem.splice(elem.indexOf(indice), 1);
            });
        }


        $scope.eliminaCondizione = function (elem, indice) {
            dialog.deleteDialog(elem, elem, "Sicuro di volere eliminare la condizione ?").then(function (result) {
                elem.fromColumns.splice(indice, 1);
                elem.toColumns.splice(indice, 1);
            });
        }

        $scope.checkKey = function (arco, prop) {

            var newProperties = {};
            var nome = arco.properties[prop].rename;
            if (arco.properties[prop].rename != prop) {

                newProperties = arco.properties[prop];
                delete arco.properties[prop];
                arco.properties[nome] = newProperties;
            }
            for (var k in arco.properties) {
                if (arco.properties[k].rename != k) {
                    newProperties = arco.properties[k];
                    delete arco.properties[k];
                    arco.properties[name] = newProperties;
                }
            }
        }


        // ** GESTIONE RGOLE DI JOIN PER ARCO
        $scope.chgFromColumns = function (elem, t, index) {
            elem.mapping[0].fromColumns[index] = t;
        }

        $scope.chgToColumns = function (elem, t, index) {
            elem.mapping[0].toColumns[index] = t;
        }

        $scope.aggiungiCondizione = function (edge) {
            $scope.indexNewColomnsTo = edge.mapping[0].toColumns.push("");
            $scope.indexNewColomnsFrom = edge.mapping[0].fromColumns.push("");
        }

        function getObject() {
            $scope.myObj = context.getObj() // setObject();
            return;
        }


        function clearPopUp() {
            document.getElementById('saveButton').onclick = null;
            document.getElementById('cancelButton').onclick = null;
            document.getElementById('network-popUp').style.display = 'none';
        }

        function cancelEdit(callback) {
            clearPopUp();
            callback(null);
        }

        function saveData(data, callback) {
            data.id = document.getElementById('node-id').value;
            data.label = document.getElementById('node-label').value;
            clearPopUp();
            callback(data);
        }

        $scope.closeOpenWhere = function (isOpen) {
            $scope.openWhere = isOpen;
        }

        $scope.elabora = function () {
            $scope.myObj.edges.forEach(function (e) {
                for (var i in e) {
                    if (e[i].mapping[0].joinTable == null || e[i].mapping[0].joinTable == undefined) {
                        e[i].relation = false;
                    }
                    else {
                        e[i].relation = true;
                    }
                }
            });
        }

        $scope.sincronyze = function () {
            $scope.verificaOggetto();
            $scope.strMessage = "";
            $scope.message = [];
            //  $scope.init = false;
            context.setObj($scope.myObj);
            var inputData = context.getTpConfig();
            inputData.migrationConfig = JSON.stringify($scope.myObj);
            inputData.strategy = "naive-aggregate";
            context.tpJob(inputData).then(function (response) {

                $scope.testTP(true);
            });


        }



        $scope.save = function (v) {
            $scope.sincronyze($scope.myOby);
            //  context.setObj($scope.myObj);
            // $scope.openWhere = true;
            //       context.getSchema();

        }
        $scope.message = [];



        //        $scope.testConnection = function (result) {
        //            $scope.$emit("wait", true);
        //            $scope.init = false;
        //            context.testConnection(result).then(function (status) {
        //                if (status > 0) {

        //                    $scope.getSchema();
        //                }
        //                else {

        //                    $scope.$emit("isConnected", false);
        //                    //dialog.confirmationDialog("Errore", "Impossibile effettuare la connessione ", "ok", "Annulla");
        //                    $scope.$emit("wait", false);
        //                    $scope.init = true;
        //                    toastr.error('<h5>impossibile caricare lo schema del db</h5>', 'Errore', {
        //                        allowHtml: true
        //                    });

        //                }

        //            },
        //             function (error) {
        //                 $scope.$emit("wait", false);
        //                 $scope.$emit("isConnected", false);
        //                 dialog.confirmationDialog("Errore", "Impossibile effettuare la connessione ", "ok", "Annulla");
        //                 $scope.init = false;

        //             });
        //        }

        $scope.closePooling = function () {
            $scope.pooling = false;

        }

        $scope.stopPooling = function () {
            $timeout.cancel($scope.timer);

        }
        $scope.strMessage = '';
        $scope.message = [];

        $scope.testTP = function (sincro) {

            // var strMessage = ''
            $scope.pooling = true;
            context.checkStatusTP().then(function (data) {
                if (data.job) {

                    if (data.job.log == '') {
                        if ($scope.message.length == 0)
                            $scope.message.push("Inizializzazione in corso ...");
                    }

                    if (data.job.log) {
                        data.job.log = data.job.log.replace($scope.strMessage, '');
                        $scope.strMessage += data.job.log;
                        data.job.log = data.job.log.replace(/\u000a\u000d/, '')
                        data.job.log = data.job.log.replace(/\u000d/g, '\n')
                        $scope.message.push('' + data.job.log);
                        $scope.$emit('openTerminal');
                        if (data.job.log.indexOf('Importing complete in ') != -1) {

                            $scope.$emit("isConnected", true);
                            return false;
                        }

                    }

                    $scope.timer = $timeout(function () {
                        $scope.testTP();
                        // $scope.$emit('openTerminal');
                    }, 3000);
                }
                else {


                    if (data.job == undefined) {
                        $scope.message.push("Nessun job in esecuzione");
                    }

                }
            }
            ,
             function (error) {

                 $scope.$emit("isConnected", false);
                 dialog.confirmationDialog("Errore", "Impossibile caricare lo schema del db", "ok", "Annulla");
                 $scope.myObj = null;
             });

        }



        $scope.validaConfigurazione = function (result) {
            $scope.isValidTP = false;

            if (!result.driver || !result.urlDb || !result.jurl || result.database == "" || result.username == "" || result.password == "") {
                dialog.confirmationDialog("campi Obbligatori", "Valorizzare tutti i campi", "ok", "Annulla");
                $scope.isValidTP = false;


            }
            else {

                $scope.isValidTP = true;

            }

            return $scope.isValidTP;
        }

        $scope.testConnection = function (conn) {

            context.verificaDb(conn).then(function (response) {

                if (response == 1) {
                    $scope.$emit("isConnected", true);
                    return true;
                }
            });
            //   return false; 
        }


        $scope.avviaTP = function (result) {
            if (!$scope.validaConfigurazione(result))
                return;
            $scope.testTP();
            $scope.strMessage = "";
            $scope.init = false;
            context.tpJob(result).then(function (response) {
                if (response.data != undefined && response.data != '') {
                    // verifico se la chiamata non è andata in errore , e comincio a verificare lo stato del job 
                    context.settpConfig(result);
                    $scope.testConnection(result);
                    $scope.myObj = response.data;
                    $scope.elabora();
                    context.setObj($scope.myObj);
                    context.setConnected(true);
                    var container = document.getElementById('mynetwork');
                    $scope.stopPooling();
                    $scope.container = container;

                    //     dialog.confirmationDialog("Connessione Configurata", "Operazione effettuata", "ok", "Annulla");
                    $scope.message.push("Operazione terminata  con successo");
                    $scope.$emit('openTerminal');

                }
                else { //la chiamata è andata in errore

                    $scope.$emit("isConnected", false);
                    dialog.confirmationDialog("Errore", "Impossibile effettuare l'operazione ", "ok", "Annulla");
                    $scope.message.push("Impossibile effettuare l'operazione");
                    $scope.init = true;
                }
            },
             function (error) {

                 $scope.$emit("isConnected", false);
                 dialog.confirmationDialog("Errore", "Impossibile effettuare l'operazione", "ok", "Annulla");
                 $scope.message.push("Impossibile effettuare l'operazione");
                 $scope.init = true;

             });

        }

        $scope.setConnection = function () {
            var item = context.getdbConfig();
        }

        $scope.setDriver = function (driver) {
            context.tpConfig.jurl = driver.value;
            $scope.item.jurl = '' + driver.value;
        }


        function getDrivers() {

            $scope.$emit("wait", true);
            var d = {};
            context.getDrivers().then(function (response) {
                if (response != undefined) {
                    for (var k in response.data) {
                        $scope.drivers.push({ name: k, value: response.data[k].format });
                    }
                }
                $scope.$emit("wait", false);
            })

        }

        function activate() {
            common.activateController([],
             controllerId)
                .then(function () {


                    // ***************** connessione reale
                    getDrivers();
                    $scope.isConnected = context.isConnected();
                    $scope.init = !$scope.isConnected;
                    if ($scope.isConnected) {
                        $scope.myObj = context.getObj();
                    }
                    $scope.item = context.getTpConfig();

                    //  ********** MOCK ******* uso i mock

                    //                    $scope.$emit("isConnected", true);
                    //                    context.setConnected(true); 
                    //                    $scope.isConnected = true; // context.isConnected();
                    //                    $scope.init = false;
                    //                    $scope.myObj = context.getObjMock();
                    //                  

                });
        }
    }
})();